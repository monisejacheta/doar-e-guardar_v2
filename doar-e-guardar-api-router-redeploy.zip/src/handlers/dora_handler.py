import json
from typing import Dict, Any
from src.utils.response import formatar_resposta_http
from src.services.dora_ia import (
    funcaoProcessarComandoLinguagemNaturalDora,
    funcaoConsultarEstoqueConversacionalDora,
    funcaoSolicitarRelatorioPorComandoDora,
    funcaoGerarAlertasPreditivosDora,
    funcaoDetectarAnomaliasEstoqueDora,
    funcaoSugerirReceitasAntidesperdicioDora,
    funcaoOrientarOperacaoUsuarioDora
)


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    corpo = (
        json.loads(event["body"])
        if isinstance(event.get("body"), str) and event.get("body")
        else (event.get("body") or event)
    )
    acao = str(corpo.get("acao", "")).lower()

    if acao == "ping":
        return formatar_resposta_http(200, {
            "sucesso": True,
            "status_code": 200,
            "mensagem": "Dora IA operacional."
        })

    mensagem = corpo.get("mensagem") or corpo.get("pergunta") or ""
    intencao = corpo.get("intencao") or funcaoProcessarComandoLinguagemNaturalDora(mensagem)

    if intencao == "receitas":
        res = funcaoSugerirReceitasAntidesperdicioDora(corpo.get("lotes_estoque"))
    elif intencao == "validade_estoque":
        res = funcaoConsultarEstoqueConversacionalDora(mensagem)
    elif intencao == "relatorios":
        res = funcaoSolicitarRelatorioPorComandoDora(mensagem, corpo.get("emails_destino"))
    elif intencao == "alertas_preditivos":
        res = funcaoGerarAlertasPreditivosDora()
    elif intencao == "anomalias":
        res = funcaoDetectarAnomaliasEstoqueDora(corpo.get("historico_saidas"))
    else:
        res = funcaoOrientarOperacaoUsuarioDora(mensagem)

    return formatar_resposta_http(res.get("status_code", 200), res)

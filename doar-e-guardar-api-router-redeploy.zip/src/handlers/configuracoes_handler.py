# backend-serverless/src/handlers/configuracoes_handler.py
import os
import json
import uuid
import boto3
from botocore.exceptions import ClientError
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional, Tuple
from src.utils.response import formatar_resposta_http

regiao = os.getenv("AWS_REGION", "us-east-2")
dynamodb = boto3.resource("dynamodb", region_name=regiao)
dynamodb_client = boto3.client("dynamodb", region_name=regiao)

tabela_lotes = dynamodb.Table("tb_lotesProdutos")

# Mapeamento oficial: tipo -> (nome_tabela_dynamodb, chave_primaria)
TABELAS_ENTIDADES: Dict[str, Tuple[str, str]] = {
    "doador": ("tb_doadores", "id_doador"),
    "campanha": ("tb_campanhasDoacoes", "id_campanha"),
    "instituicao": ("tb_instituicoes", "id_instituicao"),
    "local": ("tb_locaisArmazenamento", "id_local_armazenamento"),
    "categoria": ("tb_categoriasAlimentos", "id_categoria_alimento"),
    "motivo_saida": ("tb_motivosSaidas", "id_motivo_saida"),
    "usuario": ("tb_usuarios", "id_usuario"),
}


def _garantir_tabela_dynamo(nome_tabela: str, chave_pk: str) -> None:
    try:
        dynamodb_client.create_table(
            TableName=nome_tabela,
            KeySchema=[{"AttributeName": chave_pk, "KeyType": "HASH"}],
            AttributeDefinitions=[{"AttributeName": chave_pk, "AttributeType": "S"}],
            BillingMode="PAY_PER_REQUEST",
        )
        waiter = dynamodb_client.get_waiter("table_exists")
        waiter.wait(TableName=nome_tabela, WaiterConfig={"Delay": 2, "MaxAttempts": 15})
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "")
        if code != "ResourceInUseException":
            raise RuntimeError(
                f"Tabela DynamoDB '{nome_tabela}' (chave '{chave_pk}') não existe e não pôde ser criada automaticamente: {e}"
            )


def _executar_com_tabela(tipo: str, operacao):
    nome_tabela, chave_pk = TABELAS_ENTIDADES[tipo]
    tabela = dynamodb.Table(nome_tabela)
    try:
        return operacao(tabela, chave_pk)
    except ClientError as e:
        if e.response.get("Error", {}).get("Code") == "ResourceNotFoundException":
            _garantir_tabela_dynamo(nome_tabela, chave_pk)
            return operacao(tabela, chave_pk)
        raise


def _listar_dynamo(tipo: str) -> List[Dict[str, Any]]:
    def _scan(tabela, _pk):
        resp = tabela.scan()
        itens = resp.get("Items", [])
        while "LastEvaluatedKey" in resp:
            resp = tabela.scan(ExclusiveStartKey=resp["LastEvaluatedKey"])
            itens.extend(resp.get("Items", []))
        return itens

    try:
        return _executar_com_tabela(tipo, _scan)
    except Exception as e:
        print(f"[AVISO DYNAMO LISTAR {tipo}]: {e}")
        return []


def _salvar_dynamo(tipo: str, item_id: str, dados: Dict[str, Any]) -> Dict[str, Any]:
    def _put(tabela, chave_pk):
        registro = {
            **dados,
            chave_pk: str(item_id),
            "atualizado_em": datetime.now(timezone.utc).isoformat(),
        }
        tabela.put_item(Item=registro)
        return registro

    return _executar_com_tabela(tipo, _put)


def _excluir_dynamo(tipo: str, item_id: str) -> None:
    def _delete(tabela, chave_pk):
        tabela.delete_item(Key={chave_pk: str(item_id)})

    _executar_com_tabela(tipo, _delete)


# ==========================================
# DOADORES -> tb_doadores (PK: id_doador)
# ==========================================
def funcaoCadastrarDoador(
    nome_completo: str,
    cpf: str,
    email: str,
    telefone: str,
    endereco: str = "",
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    if not nome_completo or not str(nome_completo).strip():
        return {"sucesso": False, "status_code": 400, "mensagem": "Informe o nome do doador."}

    extras = extra or {}
    item_id = str(extras.get("id_doador") or extras.get("id") or f"doador_{uuid.uuid4().hex[:10]}")
    doador = {
        "id_doador": item_id,
        "id": item_id,
        "nome_completo": str(nome_completo).strip(),
        "nome_completo_doador": str(nome_completo).strip(),
        "tipo": str(extras.get("tipo") or "PF").upper(),
        "documento": str(cpf or extras.get("documento") or "").strip(),
        "cpf_doador": str(cpf or extras.get("documento") or "").strip(),
        "email": str(email or "").strip(),
        "email_doador": str(email or "").strip(),
        "telefone": str(telefone or "").strip(),
        "telefone_doador": str(telefone or "").strip(),
        "endereco": str(endereco or "").strip(),
        "observacoes": str(extras.get("observacoes") or endereco or "").strip(),
        "data_cadastro": str(extras.get("data_cadastro") or datetime.now(timezone.utc).strftime("%Y-%m-%d")),
        "status_ativo": extras.get("status_ativo", True) is not False,
    }
    _salvar_dynamo("doador", item_id, doador)
    return {"sucesso": True, "status_code": 201, "mensagem": "Doador salvo em tb_doadores com sucesso.", "doador": doador}


def funcaoEditarDoador(id_doador: Any, dados: Dict[str, Any]) -> Dict[str, Any]:
    item_id = str(id_doador)
    existentes = {str(d.get("id_doador")): d for d in _listar_dynamo("doador")}
    atual = dict(existentes.get(item_id, {"id_doador": item_id, "id": item_id}))
    for k, v in dados.items():
        if k not in ("modulo", "acao"):
            atual[k] = v
    if "nome_completo" in dados:
        atual["nome_completo_doador"] = dados["nome_completo"]
    if "documento" in dados:
        atual["cpf_doador"] = dados["documento"]
    _salvar_dynamo("doador", item_id, atual)
    return {"sucesso": True, "status_code": 200, "mensagem": "Doador atualizado em tb_doadores.", "doador": atual}


def funcaoConsultarDoadores(filtro: str = "") -> Dict[str, Any]:
    termo = str(filtro or "").strip().lower()
    itens = _listar_dynamo("doador")
    if termo:
        itens = [
            d for d in itens
            if termo in str(d.get("nome_completo", d.get("nome_completo_doador", ""))).lower()
            or termo in str(d.get("documento", d.get("cpf_doador", ""))).lower()
            or termo in str(d.get("email", d.get("email_doador", ""))).lower()
        ]
    return {"sucesso": True, "status_code": 200, "doadores": itens}


def funcaoExcluirDoador(id_doador: Any) -> Dict[str, Any]:
    _excluir_dynamo("doador", str(id_doador))
    return {"sucesso": True, "status_code": 200, "mensagem": "Doador removido de tb_doadores com sucesso."}


# ==========================================
# INSTITUICOES -> tb_instituicoes (PK: id_instituicao)
# ==========================================
def funcaoCadastrarInstituicao(
    nome_instituicao: str,
    cnpj: str,
    email: str,
    telefone: str,
    endereco: str,
    ids_doadores_representantes: List[Any],
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    if not nome_instituicao or not str(nome_instituicao).strip():
        return {"sucesso": False, "status_code": 400, "mensagem": "Informe o nome da instituição."}

    extras = extra or {}
    item_id = str(extras.get("id_instituicao") or extras.get("id") or f"inst_{uuid.uuid4().hex[:10]}")
    inst = {
        "id_instituicao": item_id,
        "id": item_id,
        "nome_fantasia": str(nome_instituicao).strip(),
        "nome_instituicao": str(nome_instituicao).strip(),
        "razao_social": str(extras.get("razao_social") or nome_instituicao).strip(),
        "cnpj": str(cnpj or "").strip(),
        "cnpj_instituicao": str(cnpj or "").strip(),
        "tipo_unidade": str(extras.get("tipo_unidade") or "Unidade Parceira").strip(),
        "endereco": str(endereco or "").strip(),
        "telefone": str(telefone or "").strip(),
        "email": str(email or "").strip(),
        "responsavel": str(extras.get("responsavel") or "").strip(),
        "data_fundacao": str(extras.get("data_fundacao") or datetime.now(timezone.utc).strftime("%Y-%m-%d")),
        "representantes": ids_doadores_representantes or [],
        "status_ativo": extras.get("status_ativo", True) is not False,
    }
    _salvar_dynamo("instituicao", item_id, inst)
    return {"sucesso": True, "status_code": 201, "mensagem": "Instituição salva em tb_instituicoes com sucesso.", "instituicao": inst}


def funcaoEditarInstituicao(id_instituicao: Any, dados: Dict[str, Any]) -> Dict[str, Any]:
    item_id = str(id_instituicao)
    existentes = {str(i.get("id_instituicao")): i for i in _listar_dynamo("instituicao")}
    atual = dict(existentes.get(item_id, {"id_instituicao": item_id, "id": item_id}))
    for k, v in dados.items():
        if k not in ("modulo", "acao"):
            atual[k] = v
    if "nome_fantasia" in dados:
        atual["nome_instituicao"] = dados["nome_fantasia"]
    _salvar_dynamo("instituicao", item_id, atual)
    return {"sucesso": True, "status_code": 200, "mensagem": "Instituição atualizada em tb_instituicoes.", "instituicao": atual}


def funcaoConsultarInstituicoes(filtro: str = "") -> Dict[str, Any]:
    termo = str(filtro or "").strip().lower()
    itens = _listar_dynamo("instituicao")
    if termo:
        itens = [
            i for i in itens
            if termo in str(i.get("nome_fantasia", i.get("nome_instituicao", ""))).lower()
            or termo in str(i.get("cnpj", i.get("cnpj_instituicao", ""))).lower()
        ]
    return {"sucesso": True, "status_code": 200, "instituicoes": itens}


def funcaoExcluirInstituicao(id_instituicao: Any) -> Dict[str, Any]:
    _excluir_dynamo("instituicao", str(id_instituicao))
    return {"sucesso": True, "status_code": 200, "mensagem": "Instituição removida de tb_instituicoes com sucesso."}


# ==========================================
# CATEGORIAS -> tb_categoriasAlimentos (PK: id_categoria_alimento)
# ==========================================
def funcaoCadastrarCategoriaAlimento(
    nome_categoria: str,
    nome_subcategoria: str = "",
    descricao_categoria: str = "",
) -> Dict[str, Any]:
    nome = str(nome_categoria or "").strip()
    if not nome:
        return {"sucesso": False, "status_code": 400, "mensagem": "Informe o nome da categoria."}

    for cat in _listar_dynamo("categoria"):
        if str(cat.get("nome_categoria", "")).strip().lower() == nome.lower():
            return {"sucesso": True, "status_code": 200, "categoria": cat}

    item_id = f"cat_{uuid.uuid4().hex[:10]}"
    cat = {
        "id_categoria_alimento": item_id,
        "nome_categoria": nome,
        "nome_subcategoria": str(nome_subcategoria or nome).strip(),
        "descricao_categoria": str(descricao_categoria or f"Categoria {nome}").strip(),
        "oculta": False,
        "ativo": True,
        "status_ativo": True,
    }
    _salvar_dynamo("categoria", item_id, cat)
    return {"sucesso": True, "status_code": 201, "categoria": cat}


def funcaoEditarCategoriaAlimento(id_categoria_alimento: Any, dados: Dict[str, Any]) -> Dict[str, Any]:
    item_id = str(id_categoria_alimento)
    existentes = {str(c.get("id_categoria_alimento")): c for c in _listar_dynamo("categoria")}
    if item_id not in existentes:
        return {"sucesso": False, "status_code": 404, "mensagem": "Categoria não encontrada."}
    atual = dict(existentes[item_id])
    atual.update({k: v for k, v in dados.items() if k not in ("modulo", "acao")})
    _salvar_dynamo("categoria", item_id, atual)
    return {"sucesso": True, "status_code": 200, "categoria": atual}


def funcaoInativarExcluirCategoriaAlimento(id_categoria_alimento: Any, possui_produtos_vinculados: bool = False) -> Dict[str, Any]:
    if possui_produtos_vinculados:
        return {"sucesso": False, "status_code": 409, "mensagem": "Não é possível desativar uma categoria que possui produtos cadastrados."}
    _excluir_dynamo("categoria", str(id_categoria_alimento))
    return {"sucesso": True, "status_code": 200, "mensagem": "Categoria removida com sucesso."}


def _listar_categorias_mobile() -> Dict[str, Any]:
    return {"sucesso": True, "status_code": 200, "categorias": _listar_dynamo("categoria")}


def _atualizar_visibilidade_categoria_mobile(corpo: Dict[str, Any]) -> Dict[str, Any]:
    nome = str(corpo.get("nome_categoria") or "").strip()
    oculta = bool(corpo.get("oculta", False))
    for cat in _listar_dynamo("categoria"):
        if str(cat.get("nome_categoria", "")).strip().lower() == nome.lower():
            atual = dict(cat)
            atual["oculta"] = oculta
            atual["ativo"] = not oculta
            atual["status_ativo"] = not oculta
            _salvar_dynamo("categoria", str(atual["id_categoria_alimento"]), atual)
            return {"sucesso": True, "status_code": 200, "categoria": atual}

    res = funcaoCadastrarCategoriaAlimento(nome, nome, f"Categoria {nome}")
    if res.get("sucesso") and isinstance(res.get("categoria"), dict):
        cat = res["categoria"]
        cat["oculta"] = oculta
        cat["ativo"] = not oculta
        cat["status_ativo"] = not oculta
        _salvar_dynamo("categoria", str(cat["id_categoria_alimento"]), cat)
        return {"sucesso": True, "status_code": 200, "categoria": cat}
    return {"sucesso": True, "status_code": 200, "mensagem": "Visibilidade atualizada."}


# ==========================================
# LOCAIS -> tb_locaisArmazenamento (PK: id_local_armazenamento)
# ==========================================
def funcaoCadastrarLocalArmazenamento(
    nome_local: str,
    tipo_local: str,
    sublocal_compartimento: str,
    localizacao_ambiente: str,
    id_customizado: Optional[str] = None,
    local_descricao_custom: Optional[str] = None,
) -> Dict[str, Any]:
    tipo_limpo = str(tipo_local or "armário").strip().lower()
    if tipo_limpo not in ("armário", "armario", "geladeira"):
        return {
            "sucesso": False,
            "status_code": 422,
            "mensagem": "Tipo de local não permitido. Cadastre apenas 'armário' ou 'geladeira'.",
        }
    tipo_norm = "armário" if tipo_limpo == "armario" else tipo_limpo
    nome_limpo = str(nome_local or "").strip()
    sub_limpo = str(sublocal_compartimento or "").strip()
    desc_final = str(local_descricao_custom or (f"{nome_limpo} - {sub_limpo}" if sub_limpo else nome_limpo)).strip()
    item_id = str(id_customizado or f"loc_{uuid.uuid4().hex[:10]}")

    local = {
        "id_local_armazenamento": item_id,
        "nome_local": nome_limpo,
        "tipo_local": tipo_norm,
        "sublocal_compartimento": sub_limpo,
        "localizacao_ambiente": str(localizacao_ambiente or "Despensa").strip(),
        "local_descricao": desc_final,
        "status_ativo": True,
        "possui_lotes_ativos": False,
    }
    _salvar_dynamo("local", item_id, local)
    return {"sucesso": True, "status_code": 201, "mensagem": "Prateleira salva em tb_locaisArmazenamento.", "local": local}


def funcaoEditarLocalArmazenamento(id_local_armazenamento: Any, dados: Dict[str, Any]) -> Dict[str, Any]:
    item_id = str(id_local_armazenamento)
    existentes = {str(l.get("id_local_armazenamento")): l for l in _listar_dynamo("local")}
    if item_id not in existentes:
        return {"sucesso": False, "status_code": 404, "mensagem": "Local de armazenamento não encontrado."}
    atual = dict(existentes[item_id])
    atual.update({k: v for k, v in dados.items() if k not in ("modulo", "acao")})
    _salvar_dynamo("local", item_id, atual)
    return {"sucesso": True, "status_code": 200, "local": atual}


def _local_tem_lotes_ativos_dynamo(id_local: str, desc_local: str) -> bool:
    try:
        resp = tabela_lotes.scan()
        for lote in resp.get("Items", []):
            qtd = int(lote.get("quantidade_atual_pacote", 0) or 0)
            if qtd <= 0:
                continue
            if str(lote.get("id_local_armazenamento", "")) == id_local:
                return True
            if desc_local and str(lote.get("local_descricao", "")).strip().lower() == desc_local.strip().lower():
                return True
    except Exception:
        pass
    return False


def funcaoBloquearExclusaoLocalComLotes(
    id_local_armazenamento: Any,
    possui_lotes_ativos: Optional[bool] = None,
    local_descricao: str = "",
) -> Dict[str, Any]:
    item_id = str(id_local_armazenamento)
    ocupado = possui_lotes_ativos if possui_lotes_ativos is not None else _local_tem_lotes_ativos_dynamo(item_id, local_descricao)
    if ocupado:
        return {
            "sucesso": False,
            "status_code": 409,
            "exclusao_bloqueada": True,
            "mensagem": "Não é possível remover este local porque ainda existem produtos guardados nele. Mova os lotes primeiro.",
        }
    _excluir_dynamo("local", item_id)
    return {"sucesso": True, "status_code": 200, "exclusao_bloqueada": False, "mensagem": "Local removido de tb_locaisArmazenamento."}


def _listar_locais_mobile() -> Dict[str, Any]:
    return {"sucesso": True, "status_code": 200, "locais": _listar_dynamo("local")}


def _cadastrar_local_mobile(corpo: Dict[str, Any]) -> Dict[str, Any]:
    nome_local = str(corpo.get("nome_local") or corpo.get("local_descricao") or "").strip()
    tipo_local = str(corpo.get("tipo_local") or ("geladeira" if "geladeira" in nome_local.lower() else "armário"))
    sublocal = str(corpo.get("sublocal") or corpo.get("sublocal_compartimento") or "").strip()
    ambiente = str(corpo.get("ambiente") or corpo.get("localizacao_ambiente") or "Despensa").strip()

    if corpo.get("local_descricao") and not corpo.get("nome_local"):
        partes = [p.strip() for p in str(corpo["local_descricao"]).split("-", 1)]
        nome_local = partes[0]
        if len(partes) > 1 and not sublocal:
            sublocal = partes[1]

    return funcaoCadastrarLocalArmazenamento(
        nome_local=nome_local,
        tipo_local=tipo_local,
        sublocal_compartimento=sublocal,
        localizacao_ambiente=ambiente,
        id_customizado=corpo.get("id_local_armazenamento"),
        local_descricao_custom=corpo.get("local_descricao"),
    )


def _excluir_local_mobile(corpo: Dict[str, Any]) -> Dict[str, Any]:
    id_raw = str(corpo.get("id_local") or corpo.get("id_local_armazenamento") or "")
    desc_alvo = str(corpo.get("local_descricao") or "").strip()

    if not id_raw and desc_alvo:
        for loc in _listar_dynamo("local"):
            if str(loc.get("local_descricao", "")).strip().lower() == desc_alvo.lower():
                id_raw = str(loc.get("id_local_armazenamento", ""))
                break

    if not id_raw:
        return {"sucesso": True, "status_code": 200, "exclusao_bloqueada": False, "mensagem": "Local removido."}

    return funcaoBloquearExclusaoLocalComLotes(id_raw, corpo.get("possui_lotes_ativos"), desc_alvo)


# ==========================================
# USUARIOS -> tb_usuarios (PK: id_usuario)
# MOTIVOS DE SAIDA -> tb_motivosSaidas (PK: id_motivo_saida)
# CAMPANHAS -> tb_campanhasDoacoes (PK: id_campanha)
# ==========================================
def funcaoCadastrarUsuarioSistema(nome_usuario: str, email_usuario: str, nivel_acesso_permissao: str = "voluntario") -> Dict[str, Any]:
    item_id = f"usr_{uuid.uuid4().hex[:10]}"
    usr = {
        "id_usuario": item_id,
        "nome_usuario": str(nome_usuario or "").strip(),
        "email_usuario": str(email_usuario or "").strip().lower(),
        "nivel_acesso_permissao": str(nivel_acesso_permissao or "voluntario").strip(),
        "status_ativo": True,
    }
    _salvar_dynamo("usuario", item_id, usr)
    return {"sucesso": True, "status_code": 201, "usuario": usr}


def funcaoGerenciarPermissoesUsuarios(id_usuario: Any, novo_nivel_acesso: str) -> Dict[str, Any]:
    perfis_validos = {"administrador", "funcionario_operador", "voluntario", "consulta"}
    if novo_nivel_acesso not in perfis_validos:
        return {"sucesso": False, "status_code": 400, "mensagem": "Nível de permissão inválido."}
    item_id = str(id_usuario)
    existentes = {str(u.get("id_usuario")): u for u in _listar_dynamo("usuario")}
    if item_id in existentes:
        atual = dict(existentes[item_id])
        atual["nivel_acesso_permissao"] = novo_nivel_acesso
        _salvar_dynamo("usuario", item_id, atual)
    return {"sucesso": True, "status_code": 200, "nivel_acesso_atualizado": novo_nivel_acesso}


def _crud_usuarios(subacao: str, corpo: Dict[str, Any]) -> Dict[str, Any]:
    if subacao == "cadastrar":
        return funcaoCadastrarUsuarioSistema(
            corpo.get("nome_usuario", ""),
            corpo.get("email_usuario", ""),
            corpo.get("nivel_acesso_permissao", "voluntario"),
        )
    if subacao == "atualizar":
        item_id = str(corpo.get("id_usuario") or "")
        existentes = {str(u.get("id_usuario")): u for u in _listar_dynamo("usuario")}
        if item_id not in existentes:
            return {"sucesso": False, "status_code": 404, "mensagem": "Usuário não encontrado."}
        atual = dict(existentes[item_id])
        for campo in ("nome_usuario", "email_usuario", "nivel_acesso_permissao", "status_ativo"):
            if campo in corpo:
                atual[campo] = corpo[campo]
        _salvar_dynamo("usuario", item_id, atual)
        return {"sucesso": True, "status_code": 200, "usuario": atual}
    if subacao == "excluir":
        _excluir_dynamo("usuario", str(corpo.get("id_usuario") or ""))
        return {"sucesso": True, "status_code": 200, "mensagem": "Usuário removido."}
    return {"sucesso": True, "status_code": 200, "usuarios": _listar_dynamo("usuario")}


_MOTIVOS_SAIDA_OFICIAIS: List[Dict[str, Any]] = [
    {
        "id_motivo_saida": "mot_saida_regular",
        "nome_motivo_saida": "Saida Regular",
        "exige_confirmacao_perda": False,
        "regra": "Saída normal para consumo na cozinha ou distribuição regular.",
    },
    {
        "id_motivo_saida": "mot_perda_produtos",
        "nome_motivo_saida": "Perda de produtos",
        "exige_confirmacao_perda": True,
        "regra": "Descarte por vencimento, avaria ou embalagem danificada (exige confirmação PERDA).",
    },
]


def funcaoGerenciarMotivosSaida(
    acao: str = "listar",
    nome_motivo: str = "",
    exige_perda: bool = False,
    id_motivo: Optional[str] = None,
    regra: str = "",
) -> Dict[str, Any]:
    if acao in ("cadastrar", "excluir", "editar", "atualizar"):
        return {
            "sucesso": False,
            "status_code": 403,
            "mensagem": "Os motivos de saída são fixos: apenas 'Saida Regular' e 'Perda de produtos' são permitidos.",
        }

    ids_oficiais = {m["id_motivo_saida"] for m in _MOTIVOS_SAIDA_OFICIAIS}
    existentes = _listar_dynamo("motivo_saida")
    mapa_existentes = {str(m.get("id_motivo_saida")): m for m in existentes}

    # Remove motivos extras que nao sejam os 2 oficiais
    for item in existentes:
        item_id = str(item.get("id_motivo_saida", ""))
        if item_id and item_id not in ids_oficiais:
            try:
                _excluir_dynamo("motivo_saida", item_id)
            except Exception:
                pass

    # Garante que os 2 motivos oficiais estejam gravados na tabela tb_motivosSaidas
    for oficial in _MOTIVOS_SAIDA_OFICIAIS:
        atual = mapa_existentes.get(oficial["id_motivo_saida"])
        if not atual or atual.get("nome_motivo_saida") != oficial["nome_motivo_saida"]:
            try:
                _salvar_dynamo("motivo_saida", oficial["id_motivo_saida"], oficial)
            except Exception:
                pass

    return {"sucesso": True, "status_code": 200, "motivos_saida": _MOTIVOS_SAIDA_OFICIAIS}


def _crud_campanhas(subacao: str, corpo: Dict[str, Any]) -> Dict[str, Any]:
    if subacao == "cadastrar":
        titulo = str(corpo.get("titulo") or corpo.get("nome_campanha") or "").strip()
        if not titulo:
            return {"sucesso": False, "status_code": 400, "mensagem": "Informe o título da campanha."}
        item_id = str(corpo.get("id_campanha") or f"camp_{uuid.uuid4().hex[:10]}")
        camp = {
            "id_campanha": item_id,
            "titulo": titulo,
            "meta": str(corpo.get("meta") or "").strip(),
            "descricao": str(corpo.get("descricao") or "").strip(),
            "itens_necessarios": str(corpo.get("itens_necessarios") or "").strip(),
            "responsavel": str(corpo.get("responsavel") or "").strip(),
            "status_aprovacao": str(corpo.get("status_aprovacao") or "Ativa").strip(),
            "data_fim": str(corpo.get("data_fim") or "").strip(),
        }
        _salvar_dynamo("campanha", item_id, camp)
        return {"sucesso": True, "status_code": 201, "campanha": camp}
    if subacao == "atualizar":
        item_id = str(corpo.get("id_campanha") or "")
        existentes = {str(c.get("id_campanha")): c for c in _listar_dynamo("campanha")}
        if item_id not in existentes:
            return {"sucesso": False, "status_code": 404, "mensagem": "Campanha não encontrada."}
        atual = dict(existentes[item_id])
        for campo in ("titulo", "meta", "descricao", "itens_necessarios", "responsavel", "status_aprovacao", "data_fim"):
            if campo in corpo:
                atual[campo] = corpo[campo]
        _salvar_dynamo("campanha", item_id, atual)
        return {"sucesso": True, "status_code": 200, "campanha": atual}
    if subacao == "excluir":
        _excluir_dynamo("campanha", str(corpo.get("id_campanha") or ""))
        return {"sucesso": True, "status_code": 200, "mensagem": "Campanha removida."}
    return {"sucesso": True, "status_code": 200, "campanhas": _listar_dynamo("campanha")}


def funcaoVerificarStatusSincronizacao() -> Dict[str, Any]:
    return {
        "sucesso": True,
        "status_code": 200,
        "status_sincronizacao": "SINCRONIZADO",
        "ultima_sincronizacao_utc": datetime.now(timezone.utc).isoformat(),
        "tabelas": {k: v[0] for k, v in TABELAS_ENTIDADES.items()},
        "falhas_recentes": 0,
    }


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    try:
        corpo = (
            json.loads(event["body"])
            if isinstance(event.get("body"), str) and event.get("body")
            else (event.get("body") or event)
        )
        acao = corpo.get("acao", "status_sincronizacao")

        if acao == "cadastrar_doador":
            nome = corpo.get("nome") or corpo.get("nome_completo") or ""
            cpf = corpo.get("cpf") or corpo.get("documento") or ""
            email = corpo.get("email") or ""
            telefone = corpo.get("telefone") or ""
            endereco = corpo.get("endereco") or corpo.get("observacoes") or ""
            res = funcaoCadastrarDoador(nome, cpf, email, telefone, endereco, corpo)
        elif acao == "atualizar_doador":
            res = funcaoEditarDoador(corpo.get("id_doador") or corpo.get("id"), corpo)
        elif acao == "excluir_doador":
            res = funcaoExcluirDoador(corpo.get("id_doador") or corpo.get("id"))
        elif acao == "consultar_doadores":
            res = funcaoConsultarDoadores(corpo.get("filtro", ""))
        elif acao == "cadastrar_instituicao":
            nome = corpo.get("nome") or corpo.get("nome_fantasia") or ""
            cnpj = corpo.get("cnpj") or ""
            email = corpo.get("email") or ""
            telefone = corpo.get("telefone") or ""
            endereco = corpo.get("endereco") or ""
            reps = corpo.get("representantes") or []
            res = funcaoCadastrarInstituicao(nome, cnpj, email, telefone, endereco, reps, corpo)
        elif acao == "atualizar_instituicao":
            res = funcaoEditarInstituicao(corpo.get("id_instituicao") or corpo.get("id"), corpo)
        elif acao == "excluir_instituicao":
            res = funcaoExcluirInstituicao(corpo.get("id_instituicao") or corpo.get("id"))
        elif acao == "consultar_instituicoes":
            res = funcaoConsultarInstituicoes(corpo.get("filtro", ""))
        elif acao == "listar_locais":
            res = _listar_locais_mobile()
        elif acao == "cadastrar_local":
            res = _cadastrar_local_mobile(corpo)
        elif acao == "excluir_local":
            res = _excluir_local_mobile(corpo)
        elif acao == "listar_categorias":
            res = _listar_categorias_mobile()
        elif acao == "cadastrar_categoria":
            res = funcaoCadastrarCategoriaAlimento(
                corpo.get("nome_categoria", ""),
                corpo.get("nome_subcategoria", ""),
                corpo.get("descricao_categoria", ""),
            )
        elif acao == "atualizar_visibilidade_categoria":
            res = _atualizar_visibilidade_categoria_mobile(corpo)
        elif acao == "motivos_saida":
            res = funcaoGerenciarMotivosSaida(
                corpo.get("subacao", "listar"),
                corpo.get("nome_motivo", ""),
                corpo.get("exige_perda", False),
                corpo.get("id_motivo_saida"),
                corpo.get("regra", ""),
            )
        elif acao in ("listar_usuarios", "cadastrar_usuario", "atualizar_usuario", "excluir_usuario"):
            sub = acao.split("_")[0] if acao != "listar_usuarios" else "listar"
            res = _crud_usuarios(sub, corpo)
        elif acao in ("listar_campanhas", "cadastrar_campanha", "atualizar_campanha", "excluir_campanha"):
            sub = acao.split("_")[0] if acao != "listar_campanhas" else "listar"
            res = _crud_campanhas(sub, corpo)
        elif acao == "inicializar_banco":
            from src.database.setup_dynamodb import garantir_todas_tabelas_dynamodb
            res = garantir_todas_tabelas_dynamodb()
        else:
            res = funcaoVerificarStatusSincronizacao()

        return formatar_resposta_http(res.get("status_code", 200), res)
    except Exception as erro:
        return formatar_resposta_http(500, {
            "sucesso": False,
            "status_code": 500,
            "mensagem": str(erro),
        })

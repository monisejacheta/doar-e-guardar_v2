# backend-serverless/src/database/setup_dynamodb.py
import os
import boto3
from botocore.exceptions import ClientError
from typing import Dict, Any, List, Tuple

TABELAS_OFICIAIS_DYNAMODB: List[Tuple[str, str]] = [
    ("tb_categoriasAlimentos", "id_categoria_alimento"),
    ("tb_locaisArmazenamento", "id_local_armazenamento"),
    ("tb_produtos", "id_produto"),
    ("tb_doadores", "id_doador"),
    ("tb_lotesProdutos", "id_lote_produto"),
    ("tb_motivosSaidas", "id_motivo_saida"),
    ("tb_movimentacoes", "id_movimentacao_estoque"),
    ("tb_instituicoes", "id_instituicao"),
    ("tb_campanhasDoacoes", "id_campanha"),
    ("tb_logsAuditorias", "id_log_auditoria"),
    ("tb_usuarios", "id_usuario"),
]


def garantir_todas_tabelas_dynamodb(region_name: str = "") -> Dict[str, Any]:
    """Cria/verifica todas as tabelas oficiais no DynamoDB e garante os 2 motivos de saida fixos."""
    regiao = region_name or os.getenv("AWS_REGION", "us-east-2")
    client = boto3.client("dynamodb", region_name=regiao)
    resource = boto3.resource("dynamodb", region_name=regiao)

    criadas: List[str] = []
    existentes: List[str] = []
    erros: List[str] = []

    for nome_tabela, chave_pk in TABELAS_OFICIAIS_DYNAMODB:
        try:
            client.describe_table(TableName=nome_tabela)
            existentes.append(nome_tabela)
        except ClientError as e:
            if e.response.get("Error", {}).get("Code") == "ResourceNotFoundException":
                try:
                    client.create_table(
                        TableName=nome_tabela,
                        KeySchema=[{"AttributeName": chave_pk, "KeyType": "HASH"}],
                        AttributeDefinitions=[{"AttributeName": chave_pk, "AttributeType": "S"}],
                        BillingMode="PAY_PER_REQUEST",
                    )
                    waiter = client.get_waiter("table_exists")
                    waiter.wait(TableName=nome_tabela, WaiterConfig={"Delay": 2, "MaxAttempts": 15})
                    criadas.append(nome_tabela)
                except Exception as err_create:
                    erros.append(f"{nome_tabela}: {err_create}")
            else:
                erros.append(f"{nome_tabela}: {e}")

    # Garante os 2 motivos de saida oficiais em tb_motivosSaidas
    try:
        from src.handlers.configuracoes_handler import funcaoGerenciarMotivosSaida
        funcaoGerenciarMotivosSaida("listar")
    except Exception as err_mot:
        erros.append(f"tb_motivosSaidas_seed: {err_mot}")

    return {
        "sucesso": len(erros) == 0,
        "status_code": 200 if len(erros) == 0 else 500,
        "regiao": regiao,
        "tabelas_criadas": criadas,
        "tabelas_existentes": existentes,
        "erros": erros,
    }


if __name__ == "__main__":
    import json
    print(json.dumps(garantir_todas_tabelas_dynamodb(), indent=2, ensure_ascii=False))

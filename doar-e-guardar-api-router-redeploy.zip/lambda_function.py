# backend-serverless/lambda_function.py
import json
from typing import Dict, Any
from src.utils.response import formatar_resposta_http


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    try:
        # Captura o caminho enviado pela Function URL (rawPath) ou API Gateway (path)
        path = str(event.get("rawPath") or event.get("path") or "").lower()

        # Decodifica o corpo da requisição com proteção
        corpo = {}
        if "body" in event and event["body"]:
            try:
                corpo = json.loads(event["body"]) if isinstance(event["body"], str) else event["body"]
            except Exception:
                corpo = {}

        modulo = str(corpo.get("modulo", "")).lower()

        # Rota de Autenticação (Login Google / Credenciais Firebase)
        if "/auth" in path or modulo == "auth":
            from src.handlers import auth_handler
            return auth_handler.lambda_handler(event, context)

        # Rota de Configurações (Doadores, Instituições, Locais/Prateleiras, Categorias, Motivos)
        if "/configuracoes" in path or modulo == "configuracoes":
            from src.handlers import configuracoes_handler
            return configuracoes_handler.lambda_handler(event, context)

        # Rota da Assistente Virtual Dora IA
        if "/dora" in path or modulo == "dora":
            from src.handlers import dora_handler
            return dora_handler.lambda_handler(event, context)

        # Rota de Relatórios e Envio por E-mail
        if "/relatorios" in path or modulo == "relatorios":
            from src.handlers import relatorios_handler
            return relatorios_handler.lambda_handler(event, context)

        # Rota de Campanhas
        if "/campanhas" in path or modulo == "campanhas":
            from src.handlers import campanhas_handler
            return campanhas_handler.lambda_handler(event, context)

        # Rota de Movimentação Interna
        if "/movimentacao" in path or modulo == "movimentacao":
            from src.handlers import movimentacao_handler
            return movimentacao_handler.lambda_handler(event, context)

        # Rota de Acessibilidade
        if "/acessibilidade" in path or modulo == "acessibilidade":
            from src.handlers import acessibilidade_handler
            return acessibilidade_handler.lambda_handler(event, context)

        # Rota de Estoque (Home e Telas de Estoque)
        if "/estoque" in path or modulo == "estoque":
            from src.handlers import estoque_handler
            return estoque_handler.lambda_handler(event, context)

        # Rota de Diagnóstico / Health Check
        if "/diagnostico" in path or "/health" in path or modulo == "diagnostico":
            from src.handlers import diagnostico_handler
            return diagnostico_handler.lambda_handler(event, context)

        # Rota padrão para requisições desconhecidas
        from src.handlers import estoque_handler
        return estoque_handler.lambda_handler(event, context)

    except Exception as erro:
        print(f"[ERRO CRÍTICO NO ROUTER]: {str(erro)}")
        return formatar_resposta_http(500, {
            "sucesso": False,
            "status_code": 500,
            "mensagem": f"Erro interno ao processar requisição: {str(erro)}"
        })

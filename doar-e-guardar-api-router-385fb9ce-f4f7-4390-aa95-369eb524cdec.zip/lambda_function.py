# backend-serverless/lambda_function.py
import json
from typing import Dict, Any
from src.utils.response import formatar_resposta_http

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    try:
        # Captura o caminho enviado pela Function URL (rawPath) ou API Gateway (path)
        path = str(event.get("rawPath") or event.get("path") or "").lower()

        # Decodifica o corpo da requisição com proteção
        corpo = {}
        if "body" in event and event["body"]:
            try:
                corpo = json.loads(event["body"]) if isinstance(event["body"], str) else event["body"]
            except Exception:
                corpo = {}

        modulo = str(corpo.get("modulo", "")).lower()

        # Rota de Estoque (Home e Telas de Estoque)
        if "/estoque" in path or modulo == "estoque":
            from src.handlers import estoque_handler
            return estoque_handler.lambda_handler(event, context)

        # Rota de Diagnóstico / Health Check
        if "/diagnostico" in path or "/health" in path:
            from src.handlers import diagnostico_handler
            return diagnostico_handler.lambda_handler(event, context)

        # Rota padrão para requisições desconhecidas
        from src.handlers import estoque_handler
        return estoque_handler.lambda_handler(event, context)

    except Exception as erro:
        print(f"[ERRO CRÍTICO NO ROUTER]: {str(erro)}")
        return formatar_resposta_http(500, {
            "sucesso": False,
            "status_code": 500,
            "mensagem": f"Erro interno ao processar requisição: {str(erro)}"
        })
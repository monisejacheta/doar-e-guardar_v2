#!/bin/bash
# Script de Deploy Automatizado para AWS Lambda - Doar&Guardar 2.0
# Região Padrão: sa-east-1 (São Paulo)

AWS_REGION="sa-east-1"
RUNTIME="python3.12"
ZIP_FILE="doar-e-guardar-aws-lambda.zip"
ROLE_ARN="arn:aws:iam::SEU_ACCOUNT_ID_AQUI:role/doar-e-guardar-lambda-role"

echo "Iniciando deploy das funcoes serverless Doar&Guardar 2.0 na regiao $AWS_REGION..."

# Opcao A: Funcao Lambda Unificada (Roteador Central)
aws lambda create-function \
  --function-name doar-e-guardar-api-router \
  --runtime $RUNTIME \
  --role $ROLE_ARN \
  --handler lambda_function.lambda_handler \
  --zip-file fileb://$ZIP_FILE \
  --timeout 15 \
  --memory-size 256 \
  --region $AWS_REGION

# Opcao B: Microsservicos Atomizados por Modulo (mesmo pacote ZIP, handlers especificos)
declare -A HANDLERS=(
  ["doar-e-guardar-auth"]="src.handlers.auth_handler.lambda_handler"
  ["doar-e-guardar-acessibilidade"]="src.handlers.acessibilidade_handler.lambda_handler"
  ["doar-e-guardar-estoque"]="src.handlers.estoque_handler.lambda_handler"
  ["doar-e-guardar-movimentacao"]="src.handlers.movimentacao_handler.lambda_handler"
  ["doar-e-guardar-relatorios"]="src.handlers.relatorios_handler.lambda_handler"
  ["doar-e-guardar-dora-ia"]="src.handlers.dora_handler.lambda_handler"
  ["doar-e-guardar-configuracoes"]="src.handlers.configuracoes_handler.lambda_handler"
  ["doar-e-guardar-campanhas"]="src.handlers.campanhas_handler.lambda_handler"
  ["doar-e-guardar-diagnostico"]="src.handlers.diagnostico_handler.lambda_handler"
)

for FUNC_NAME in "${!HANDLERS[@]}"; do
  HANDLER_PATH="${HANDLERS[$FUNC_NAME]}"
  echo "Publicando $FUNC_NAME -> $HANDLER_PATH ..."
  aws lambda create-function \
    --function-name "$FUNC_NAME" \
    --runtime "$RUNTIME" \
    --role "$ROLE_ARN" \
    --handler "$HANDLER_PATH" \
    --zip-file "fileb://$ZIP_FILE" \
    --timeout 15 \
    --memory-size 256 \
    --region "$AWS_REGION" || \
  aws lambda update-function-code \
    --function-name "$FUNC_NAME" \
    --zip-file "fileb://$ZIP_FILE" \
    --region "$AWS_REGION"
done

echo "Deploy concluido com sucesso!"

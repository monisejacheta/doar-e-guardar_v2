import json
from typing import Dict, Any

def formatar_resposta_http(status_code: int, dados: Dict[str, Any]) -> Dict[str, Any]:
    """Formata a resposta sem duplicar os cabeçalhos de CORS gerenciados pela AWS."""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json; charset=utf-8"
        },
        "body": json.dumps(dados, ensure_ascii=False, default=str)
    }
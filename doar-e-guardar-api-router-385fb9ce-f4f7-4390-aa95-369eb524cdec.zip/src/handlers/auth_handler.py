# backend-serverless/src/handlers/auth_handler.py
import json
from typing import Dict, Any
from src.utils.response import formatar_resposta_http

def funcaoProcessarLogin(dados: Dict[str, Any]) -> Dict[str, Any]:
    """
    Processa o login federado do Firebase Auth / Google.
    Os dados do perfil chegam diretamente do Firebase no cliente.
    """
    try:
        perfil = dados.get("perfil_usuario", {})
        id_token = dados.get("id_token", "")

        # Extrai os dados reais enviados pelo Firebase
        uid = str(perfil.get("id") or dados.get("uid") or "usr_operador")
        nome = str(perfil.get("name") or "Colaborador")
        email = str(perfil.get("email") or "")
        foto = str(perfil.get("foto") or "")

        usuario_autenticado = {
            "id_usuario": uid,
            "nome_usuario": nome,
            "email_usuario": email,
            "url_foto_perfil": foto,
            "nivel_acesso_permissao": "funcionario_operador",
            "token_sessao": id_token[:30] + "..." if len(id_token) > 30 else id_token
        }

        # Tentativa opcional de auditoria sem bloquear o fluxo caso a tabela não exista
        try:
            import os
            import boto3
            dynamodb = boto3.resource("dynamodb", region_name=os.getenv("AWS_REGION", "us-east-2"))
            tabela_audit = dynamodb.Table("tb_logsAuditorias")
            tabela_audit.put_item(
                Item={
                    "id_log_auditoria": f"log_login_{uid}_{int(hash(id_token) % 1000000)}",
                    "id_usuario_responsavel": email or uid,
                    "tipo_acao_executada": "login_firebase_google",
                    "detalhe_operacao": f"Acesso autorizado para {nome} ({email})",
                    "data_hora_acao": dados.get("data_hora", "")
                }
            )
        except Exception as erro_log:
            print(f"[AVISO LOG AUDITORIA]: {erro_log}")

        return {
            "sucesso": True,
            "status_code": 200,
            "mensagem": f"Seja bem-vindo(a), {nome}!",
            "usuario": usuario_autenticado
        }
    except Exception as erro:
        print(f"[ERRO LOGIN HANDLER]: {str(erro)}")
        return {
            "sucesso": False,
            "status_code": 500,
            "mensagem": f"Erro interno ao validar login: {str(erro)}"
        }

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    corpo = {}
    if "body" in event and event["body"]:
        try:
            corpo = json.loads(event["body"]) if isinstance(event["body"], str) else event["body"]
        except Exception:
            corpo = {}

    resultado = funcaoProcessarLogin(corpo)
    return formatar_resposta_http(resultado.get("status_code", 200), resultado)
import json
from datetime import date, datetime
from typing import Dict, Any, List, Optional
from src.utils.response import formatar_resposta_http

_CAMPANHAS: Dict[int, Dict[str, Any]] = {
    1: {
        "id_campanha_doacao": 1,
        "id_doador_responsavel": 1,
        "nome_campanha": "Natal Sem Fome - Casa da Criança",
        "objetivo_descricao_campanha": "Arrecadação de leite e cereais para as famílias atendidas.",
        "data_inicio_campanha": "2026-10-01",
        "data_termino_campanha": "2026-12-20",
        "status_campanha": "Aprovada",
        "justificativa_parecer_tecnico": "Campanha homologada pela equipe técnica.",
        "itens": [
            {"nome_item_solicitado": "Leite Integral 1L", "quantidade_meta_pretendida": 100, "quantidade_final_arrecadada": 0}
        ]
    }
}

def funcaoCarregarMapaLocalizacaoOng(api_maps_disponivel: bool = True) -> Dict[str, Any]:
    """63. Integra a API do Google Maps na página pública para exibir o endereço da Casa da Criança (com fallback textual)."""
    dados_base = {
        "instituicao": "Casa da Criança de Itapira",
        "endereco_completo": "Rua da Saudade, Centro - Itapira/SP",
        "horario_atendimento": "Segunda a Sexta, das 08h às 17h",
        "coordenadas": {"latitude": -22.4357, "longitude": -46.8222}
    }
    if not api_maps_disponivel:
        dados_base["modo_fallback_textual"] = True
        dados_base["orientacao_rota"] = "Próximo à Praça Central. Entregas podem ser feitas pela portaria principal."
    else:
        dados_base["modo_fallback_textual"] = False
    return {"sucesso": True, "status_code": 200, "localizacao": dados_base}

def funcaoValidarRegrasFormularioCampanha(data_inicio: str, data_termino: str, itens_meta: List[Dict[str, Any]]) -> Dict[str, Any]:
    """65. Bloqueia o envio de propostas de campanha caso a data final seja anterior à inicial ou sem itens adicionados."""
    if not itens_meta or len(itens_meta) == 0:
        return {
            "sucesso": False,
            "status_code": 400,
            "mensagem": "Adicione pelo menos um item à meta da campanha antes de enviar."
        }
    dt_ini = date.fromisoformat(data_inicio)
    dt_fim = date.fromisoformat(data_termino)
    if dt_fim < dt_ini:
        return {
            "sucesso": False,
            "status_code": 400,
            "mensagem": "A data de término da campanha não pode ser anterior à data de início."
        }
    return {"sucesso": True, "status_code": 200, "mensagem": "Formulário de campanha válido."}

def funcaoCriarPropostaCampanhaDoacao(
    id_doador_responsavel: int,
    nome_campanha: str,
    objetivo_descricao: str,
    data_inicio: str,
    data_termino: str,
    itens_meta: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """64. Registra uma iniciativa de arrecadação proposta por um doador logado com status inicial 'Pendente de Análise'."""
    validacao = funcaoValidarRegrasFormularioCampanha(data_inicio, data_termino, itens_meta)
    if not validacao["sucesso"]:
        return validacao

    novo_id = len(_CAMPANHAS) + 1
    campanha = {
        "id_campanha_doacao": novo_id,
        "id_doador_responsavel": id_doador_responsavel,
        "nome_campanha": nome_campanha.strip(),
        "objetivo_descricao_campanha": objetivo_descricao.strip(),
        "data_inicio_campanha": data_inicio,
        "data_termino_campanha": data_termino,
        "status_campanha": "Pendente de Análise",
        "justificativa_parecer_tecnico": "",
        "itens": itens_meta
    }
    _CAMPANHAS[novo_id] = campanha
    return {
        "sucesso": True,
        "status_code": 201,
        "mensagem": "Sua proposta de campanha foi enviada e está Pendente de Análise pela equipe da Casa da Criança.",
        "campanha": campanha
    }

def funcaoCalcularDiasRestantesCampanha(data_termino_campanha: str, data_referencia: Optional[str] = None) -> Dict[str, Any]:
    """66. Calcula regressivamente o prazo restante de vigência das campanhas criadas pelo doador."""
    hoje = date.fromisoformat(data_referencia) if data_referencia else date(2026, 10, 20)
    fim = date.fromisoformat(data_termino_campanha)
    dias = max(0, (fim - hoje).days)
    return {
        "sucesso": True,
        "status_code": 200,
        "dias_restantes": dias,
        "encerrada_por_prazo": fim < hoje
    }

def funcaoAprovarCampanhaDoacao(id_campanha_doacao: int, id_usuario_moderador: str, orientacoes_entrega: str = "") -> Dict[str, Any]:
    """67. Homologa uma proposta de campanha na fila administrativa e publica automaticamente na vitrine do site."""
    if id_campanha_doacao not in _CAMPANHAS:
        return {"sucesso": False, "status_code": 404, "mensagem": "Campanha não encontrada."}
    _CAMPANHAS[id_campanha_doacao]["status_campanha"] = "Aprovada"
    _CAMPANHAS[id_campanha_doacao]["id_usuario_moderador"] = id_usuario_moderador
    _CAMPANHAS[id_campanha_doacao]["justificativa_parecer_tecnico"] = orientacoes_entrega or "Aprovada para publicação."
    return {
        "sucesso": True,
        "status_code": 200,
        "publicada_vitrine_publica": True,
        "mensagem": "Campanha aprovada e publicada na vitrine pública do portal web.",
        "campanha": _CAMPANHAS[id_campanha_doacao]
    }

def funcaoReprovarCampanhaComJustificativa(id_campanha_doacao: int, id_usuario_moderador: str, justificativa_parecer_tecnico: str) -> Dict[str, Any]:
    """68. Recusa uma proposta de campanha na fila de moderação, exigindo preenchimento obrigatório de parecer técnico."""
    if not justificativa_parecer_tecnico or not justificativa_parecer_tecnico.strip():
        return {
            "sucesso": False,
            "status_code": 400,
            "mensagem": "É obrigatório escrever o motivo da recusa para orientar o doador."
        }
    if id_campanha_doacao not in _CAMPANHAS:
        return {"sucesso": False, "status_code": 404, "mensagem": "Campanha não encontrada."}
    _CAMPANHAS[id_campanha_doacao]["status_campanha"] = "Reprovada"
    _CAMPANHAS[id_campanha_doacao]["id_usuario_moderador"] = id_usuario_moderador
    _CAMPANHAS[id_campanha_doacao]["justificativa_parecer_tecnico"] = justificativa_parecer_tecnico.strip()
    return {
        "sucesso": True,
        "status_code": 200,
        "mensagem": "Campanha reprovada com registro do parecer técnico.",
        "campanha": _CAMPANHAS[id_campanha_doacao]
    }

def funcaoRegistrarBalancoFinalCampanha(id_campanha_doacao: int, itens_arrecadados: List[Dict[str, Any]], campanha_encerrada: bool = True) -> Dict[str, Any]:
    """69. Libera e salva o preenchimento das quantidades reais arrecadadas somente após o encerramento da vigência."""
    if not campanha_encerrada:
        return {
            "sucesso": False,
            "status_code": 403,
            "mensagem": "O preenchimento da quantidade final arrecadada só é liberado após o término da campanha."
        }
    if id_campanha_doacao in _CAMPANHAS:
        _CAMPANHAS[id_campanha_doacao]["status_campanha"] = "Encerrada"
        _CAMPANHAS[id_campanha_doacao]["itens"] = itens_arrecadados
    return {
        "sucesso": True,
        "status_code": 200,
        "mensagem": "Balanço final da campanha registrado com sucesso."
    }

def funcaoCarregarIndicadoresDashboardWeb() -> Dict[str, Any]:
    """70. Consolida os KPIs administrativos na web (total estocado, alertas críticos, lotes a vencer e fila de campanhas)."""
    return {
        "sucesso": True,
        "status_code": 200,
        "kpis": {
            "total_pacotes_estocados": 26,
            "alertas_estoque_critico": 1,
            "lotes_proximos_vencimento": 1,
            "campanhas_pendentes_moderacao": sum(1 for c in _CAMPANHAS.values() if c["status_campanha"] == "Pendente de Análise")
        }
    }

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    corpo = json.loads(event["body"]) if isinstance(event.get("body"), str) and event.get("body") else (event.get("body") or event)
    acao = corpo.get("acao", "dashboard")
    if acao == "mapa_ong":
        res = funcaoCarregarMapaLocalizacaoOng(corpo.get("api_maps_disponivel", True))
    elif acao == "criar_campanha":
        res = funcaoCriarPropostaCampanhaDoacao(
            int(corpo.get("id_doador", 1)),
            corpo.get("nome_campanha", ""),
            corpo.get("objetivo", ""),
            corpo.get("data_inicio", "2026-10-20"),
            corpo.get("data_termino", "2026-11-20"),
            corpo.get("itens", [])
        )
    elif acao == "aprovar_campanha":
        res = funcaoAprovarCampanhaDoacao(int(corpo.get("id_campanha", 1)), corpo.get("id_moderador", "admin"), corpo.get("orientacoes", ""))
    elif acao == "reprovar_campanha":
        res = funcaoReprovarCampanhaComJustificativa(int(corpo.get("id_campanha", 1)), corpo.get("id_moderador", "admin"), corpo.get("justificativa", ""))
    elif acao == "balanco_final":
        res = funcaoRegistrarBalancoFinalCampanha(int(corpo.get("id_campanha", 1)), corpo.get("itens", []), corpo.get("campanha_encerrada", True))
    else:
        res = funcaoCarregarIndicadoresDashboardWeb()
    return formatar_resposta_http(res.get("status_code", 200), res)

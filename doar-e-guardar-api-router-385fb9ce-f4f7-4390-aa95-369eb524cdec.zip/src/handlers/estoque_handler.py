# backend-serverless/src/handlers/estoque_handler.py
import os
import gzip
import json
import uuid
import boto3
import urllib.request
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, Optional, List
from boto3.dynamodb.conditions import Attr
from src.utils.response import formatar_resposta_http

regiao = os.getenv("AWS_REGION", "us-east-2")
dynamodb = boto3.resource("dynamodb", region_name=regiao)

# TABELAS DO BANCO DE DADOS
tabela_produtos = dynamodb.Table("tb_produtos")
tabela_lotes = dynamodb.Table("tb_lotesProdutos")
tabela_movimentacoes = dynamodb.Table("tb_movimentacoes")

FOTO_PLACEHOLDER_PADRAO = (
    "https://images.unsplash.com/photo-1584473457406-6240486418e9?auto=format&fit=crop&w=400&q=80"
)
TIMEOUT_API = 2.0  # Timeout curto de 2s por API

def obter_data_hora_atual():
    fuso_br = timezone(timedelta(hours=-3))
    return datetime.now(fuso_br).strftime("%Y-%m-%dT%H:%M:%S")

def _ler_json_resposta(resp) -> Dict[str, Any]:
    dados_brutos = resp.read()
    if dados_brutos.startswith(b"\x1f\x8b") or resp.headers.get("Content-Encoding") == "gzip":
        dados_brutos = gzip.decompress(dados_brutos)
    try:
        texto = dados_brutos.decode("utf-8")
    except UnicodeDecodeError:
        texto = dados_brutos.decode("latin-1", errors="ignore")
    return json.loads(texto)

def _categorizar_alimento_br(texto: str, ncm: str = "") -> str:
    ncm_limpo = str(ncm or "").strip()
    if ncm_limpo.startswith(("0401", "0402", "0403", "0405", "0406")): return "Laticínios"
    if ncm_limpo.startswith(("1902", "1905")): return "Massas"
    if ncm_limpo.startswith(("1507", "1508", "1509", "1511", "1512", "1515", "1517")): return "Óleos e Gorduras"
    if ncm_limpo.startswith(("1604", "2001", "2002", "2004", "2005", "2103")): return "Enlatados"
    if ncm_limpo.startswith(("3401", "3402", "2828", "3808", "3306")): return "Higiene e Limpeza"

    t = (texto or "").lower()
    if any(k in t for k in ["leite", "milk", "queijo", "iogurte", "manteiga", "requeijao", "requeijão"]): return "Laticínios"
    if any(k in t for k in ["biscoito", "bolacha", "torrada", "massa", "macarrão", "macarrao", "espaguete", "wafer"]): return "Massas"
    if any(k in t for k in ["óleo", "oleo", "azeite", "gordura", "margarina"]): return "Óleos e Gorduras"
    if any(k in t for k in ["conserva", "enlatado", "sardinha", "atum", "milho", "ervilha", "molho", "extrato"]): return "Enlatados"
    if any(k in t for k in ["higiene", "limpeza", "sabão", "sabao", "detergente", "sabonete", "desinfetante"]): return "Higiene e Limpeza"
    return "Grãos e Cereais"


# --- MÓDULO 1: BUSCA DE PRODUTO NAS APIS ---

def _consultar_api1_eanpictures(ean: str, logs: List[str]) -> Optional[Dict[str, Any]]:
    try:
        url = f"http://www.eanpictures.com.br:9000/api/desc/{ean}"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"}, method="GET")
        with urllib.request.urlopen(req, timeout=TIMEOUT_API) as resp:
            dados = _ler_json_resposta(resp)
            nome = (dados.get("Nome") or dados.get("nome") or "").strip()
            if str(dados.get("Status", "")) == "200" and nome and "nao encontrada" not in nome.lower():
                marca = (dados.get("Marca") or dados.get("marca") or "").strip()
                ncm = str(dados.get("Ncm") or "").strip()
                foto = f"https://wsrv.nl/?url=http://www.eanpictures.com.br:9000/api/gtin/{ean}&w=400&output=jpg"
                logs.append("API 1 (EANPictures): Sucesso 200")
                return {
                    "nome": nome.title() if nome.isupper() else nome,
                    "marca": marca.title() if marca.isupper() else marca,
                    "categoria": _categorizar_alimento_br(nome, ncm),
                    "foto": foto,
                    "origem": "API 1 (EAN Pictures Brasil)",
                }
            logs.append(f"API 1 (EANPictures): Vazio ({dados.get('StatusDesc', 'Sem cadastro')})")
    except Exception as e:
        logs.append(f"API 1 (EANPictures): Erro ({str(e)})")
    return None

def _consultar_api2_openfoodfacts(ean: str, logs: List[str]) -> Optional[Dict[str, Any]]:
    try:
        url = f"https://world.openfoodfacts.org/api/v2/product/{ean}.json"
        req = urllib.request.Request(url, headers={"User-Agent": "DoarEGuardar/2.0"}, method="GET")
        with urllib.request.urlopen(req, timeout=TIMEOUT_API) as resp:
            dados = _ler_json_resposta(resp)
            if dados.get("status") == 1 and "product" in dados:
                p = dados["product"]
                nome = p.get("product_name_pt") or p.get("product_name") or p.get("generic_name_pt")
                if nome:
                    marca = (p.get("brands") or "").split(",")[0].strip()
                    foto = p.get("image_front_url") or p.get("image_url") or FOTO_PLACEHOLDER_PADRAO
                    logs.append("API 2 (OpenFoodFacts): Sucesso 200")
                    return {
                        "nome": nome.strip(),
                        "marca": marca,
                        "categoria": _categorizar_alimento_br(f"{nome} {p.get('categories', '')}"),
                        "foto": foto,
                        "origem": "API 2 (Open Food Facts)",
                    }
            logs.append("API 2 (OpenFoodFacts): Produto não consta na base")
    except Exception as e:
        logs.append(f"API 2 (OpenFoodFacts): Erro ({str(e)})")
    return None

def _consultar_api3_opengtindb_upc(ean: str, logs: List[str]) -> Optional[Dict[str, Any]]:
    try:
        url = f"https://api.upcitemdb.com/prod/trial/lookup?upc={ean}"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Accept": "application/json"}, method="GET")
        with urllib.request.urlopen(req, timeout=TIMEOUT_API) as resp:
            dados = _ler_json_resposta(resp)
            itens = dados.get("items", [])
            if itens:
                item = itens[0]
                titulo = (item.get("title") or "").strip()
                if titulo:
                    marca = (item.get("brand") or "").strip()
                    imgs = item.get("images", [])
                    foto = imgs[0] if imgs else FOTO_PLACEHOLDER_PADRAO
                    logs.append("API 3 (UPCItemDB): Sucesso 200")
                    return {
                        "nome": titulo,
                        "marca": marca,
                        "categoria": _categorizar_alimento_br(titulo),
                        "foto": foto,
                        "origem": "API 3 (Base Global UPC/EAN)",
                    }
            logs.append("API 3 (UPCItemDB): Vazio")
    except Exception as e:
        logs.append(f"API 3 (UPCItemDB): Erro ({str(e)})")
    return None

def funcaoProcessarCodigoBarrasRealinhado(codigo_barra: str) -> Dict[str, Any]:
    logs_cascata: List[str] = []
    try:
        codigo_limpo = str(codigo_barra).strip()

        resp_prod = tabela_produtos.scan(FilterExpression=Attr("codigo_barra_produto").eq(codigo_limpo))
        itens_prod = resp_prod.get("Items", [])
        if not itens_prod:
            resp_lotes = tabela_lotes.scan(FilterExpression=Attr("codigo_barra_produto").eq(codigo_limpo), Limit=1)
            itens_prod = resp_lotes.get("Items", [])

        ja_existe = len(itens_prod) > 0

        dados_api = _consultar_api1_eanpictures(codigo_limpo, logs_cascata)
        if not dados_api:
            dados_api = _consultar_api2_openfoodfacts(codigo_limpo, logs_cascata)
        if not dados_api:
            dados_api = _consultar_api3_opengtindb_upc(codigo_limpo, logs_cascata)

        if ja_existe:
            item_banco = itens_prod[0]
            return {
                "sucesso": True,
                "status_code": 200,
                "existe_no_banco": True,
                "diagnostico_apis": logs_cascata,
                "produto": {
                    "id_produto": item_banco.get("id_produto", f"prod_{codigo_limpo}"),
                    "nome_produto": item_banco.get("nome_produto") or (dados_api["nome"] if dados_api else "Produto Cadastrado"),
                    "marca_produto": item_banco.get("marca_produto") or (dados_api["marca"] if dados_api else ""),
                    "categoria": item_banco.get("categoria") or (dados_api["categoria"] if dados_api else "Grãos e Cereais"),
                    "unidade_medida_pacote": item_banco.get("unidade_medida_pacote", "pacotes"),
                    "url_foto_produto": item_banco.get("url_foto_produto") or (dados_api["foto"] if dados_api else FOTO_PLACEHOLDER_PADRAO),
                    "estoque_minimo_pacote": int(item_banco.get("estoque_minimo_pacote", 10)),
                    "codigo_barra_produto": codigo_limpo,
                    "origem": "Catálogo Interno (DynamoDB)",
                },
            }

        return {
            "sucesso": True,
            "status_code": 200,
            "existe_no_banco": False,
            "diagnostico_apis": logs_cascata,
            "produto": {
                "id_produto": f"prod_{codigo_limpo}",
                "nome_produto": dados_api["nome"],
                "marca_produto": dados_api["marca"],
                "categoria": dados_api["categoria"],
                "unidade_medida_pacote": "pacotes",
                "url_foto_produto": dados_api["foto"],
                "estoque_minimo_pacote": 10,
                "codigo_barra_produto": codigo_limpo,
                "origem": dados_api["origem"],
            } if dados_api else None,
            "origem": dados_api["origem"] if dados_api else "Item não encontrado nas APIs externas",
        }
    except Exception as erro:
        return {"sucesso": False, "status_code": 500, "diagnostico_apis": logs_cascata, "mensagem": str(erro)}


# --- MÓDULO 2: GESTÃO E OPERAÇÕES DO ESTOQUE ---

def funcaoConsultarEstoqueReal() -> Dict[str, Any]:
    try:
        resp = tabela_lotes.scan()
        itens = resp.get("Items", [])
        for item in itens:
            item["quantidade_atual_pacote"] = int(item.get("quantidade_atual_pacote", 0))
            item["estoque_minimo_pacote"] = int(item.get("estoque_minimo_pacote", 10))
            if not item.get("url_foto_produto"):
                item["url_foto_produto"] = FOTO_PLACEHOLDER_PADRAO
            if not item.get("unidade_medida_pacote"):
                item["unidade_medida_pacote"] = "pacotes"
        itens.sort(key=lambda x: str(x.get("data_validade_lote", "9999-99-99")))
        return {
            "sucesso": True,
            "status_code": 200,
            "total_pacotes": sum(i["quantidade_atual_pacote"] for i in itens),
            "total_lotes_ativos": len(itens),
            "lotes": itens,
        }
    except Exception as erro:
        return {"sucesso": False, "status_code": 500, "mensagem": str(erro)}


def funcaoCadastrarLote(dados_lote: Dict[str, Any]) -> Dict[str, Any]:
    try:
        id_lote = str(dados_lote.get("id_lote_produto", f"lote_{uuid.uuid4().hex[:8]}"))
        id_prod = str(dados_lote.get("id_produto", f"prod_{uuid.uuid4().hex[:8]}"))
        qtd = int(dados_lote.get("quantidade_inicial_pacote", 0))
        agora_iso = datetime.now(timezone.utc).isoformat()

        url_foto = dados_lote.get("url_foto_produto") or FOTO_PLACEHOLDER_PADRAO
        unidade_medida = dados_lote.get("unidade_medida_pacote", "pacotes")
        categoria = str(dados_lote.get("categoria", "Grãos e Cereais"))

        item_lote = {
            "id_lote_produto": id_lote,
            "id_produto": id_prod,
            "nome_produto": str(dados_lote.get("nome_produto", "")),
            "marca_produto": str(dados_lote.get("marca_produto", "")),
            "categoria": categoria,
            "codigo_barra_produto": str(dados_lote.get("codigo_barra_produto", "")),
            "numero_codigo_lote": str(dados_lote.get("numero_codigo_lote", "")),
            "quantidade_atual_pacote": qtd,
            "quantidade_inicial_pacote": qtd,
            "unidade_medida_pacote": unidade_medida,
            "estoque_minimo_pacote": int(dados_lote.get("estoque_minimo_pacote", 10)),
            "data_entrada_lote": str(dados_lote.get("data_entrada_lote", obter_data_hora_atual())),
            "data_validade_lote": str(dados_lote.get("data_validade_lote", "")),
            "status_validade_lote": str(dados_lote.get("status_validade_lote", "regular")),
            "id_local_armazenamento": str(dados_lote.get("id_local_armazenamento", "")),
            "local_descricao": str(dados_lote.get("local_descricao", "")),
            "url_foto_produto": url_foto,
        }
        tabela_lotes.put_item(Item=item_lote)

        tabela_produtos.put_item(
            Item={
                "id_produto": id_prod,
                "codigo_barra_produto": str(dados_lote.get("codigo_barra_produto", "")),
                "nome_produto": str(dados_lote.get("nome_produto", "")),
                "marca_produto": str(dados_lote.get("marca_produto", "")),
                "categoria": categoria,
                "unidade_medida_pacote": unidade_medida,
                "estoque_minimo_pacote": int(dados_lote.get("estoque_minimo_pacote", 10)),
                "url_foto_produto": url_foto,
                "data_cadastro_produto": agora_iso,
            }
        )

        # 🚀 GRAVA O HISTÓRICO DE ENTRADA NA tb_movimentacoes
        id_mov = f"mov_{uuid.uuid4().hex}"
        movimentacao = {
            "id_movimentacao_estoque": id_mov,
            "id_lote_produto": id_lote,
            "id_produto": id_prod,
            "ean": item_lote["codigo_barra_produto"],
            "nome": item_lote["nome_produto"],
            "categoria": item_lote["categoria"],
            "operacao": "Entrada",
            "qtd": qtd,
            "data": obter_data_hora_atual(),
            "responsavel": dados_lote.get("id_usuario", "Sistema"),
            "lote": item_lote["numero_codigo_lote"],
            "local": item_lote["local_descricao"],
            "motivo_saida": "Entrada de Produto",
            "justificativa": "Entrada manual no estoque"
        }
        tabela_movimentacoes.put_item(Item=movimentacao)

        return {
            "sucesso": True,
            "status_code": 201,
            "mensagem": "Lote gravado e entrada registrada com sucesso!",
            "lote": item_lote,
        }
    except Exception as erro:
        return {"sucesso": False, "status_code": 500, "mensagem": str(erro)}


def remover_estoque(corpo: Dict[str, Any]) -> Dict[str, Any]:
    try:
        lote = corpo.get("lote", {})
        id_lote = lote.get("id_lote_produto") or corpo.get("id_lote_produto")
        qtd_solicitada = int(corpo.get("quantidade", 0))
        motivo = str(corpo.get("motivo_saida", "")).lower()
        palavra = str(corpo.get("palavra_confirmacao", "")).strip()
        justificativa = str(corpo.get("justificativa", "")).strip()
        responsavel = corpo.get("id_usuario", "Sistema")

        if qtd_solicitada <= 0:
            return {"sucesso": False, "status_code": 400, "mensagem": "Quantidade deve ser maior que zero."}

        resp = tabela_lotes.get_item(Key={"id_lote_produto": id_lote})
        lote_banco = resp.get("Item")
        if not lote_banco:
            return {"sucesso": False, "status_code": 404, "mensagem": "Lote não encontrado no banco."}

        saldo = int(lote_banco.get("quantidade_atual_pacote", 0))
        if qtd_solicitada > saldo:
            return {"sucesso": False, "status_code": 422, "mensagem": f"Saldo insuficiente. Disponível: {saldo}"}

        if "perda" in motivo or "descarte" in motivo:
            if palavra != "PERDA":
                return {"sucesso": False, "status_code": 403, "mensagem": "Digite 'PERDA' em maiúsculas."}

        # Atualiza saldo na tabela principal de lotes
        novo_saldo = saldo - qtd_solicitada
        tabela_lotes.update_item(
            Key={"id_lote_produto": id_lote},
            UpdateExpression="SET quantidade_atual_pacote = :val",
            ExpressionAttributeValues={":val": novo_saldo}
        )

        # 🚀 GRAVA O HISTÓRICO DE SAÍDA NA tb_movimentacoes
        id_mov = f"mov_{uuid.uuid4().hex}"
        movimentacao = {
            "id_movimentacao_estoque": id_mov,
            "id_lote_produto": id_lote,
            "id_produto": lote_banco.get("id_produto", ""),
            "ean": lote_banco.get("codigo_barra_produto", ""),
            "nome": lote_banco.get("nome_produto", ""),
            "categoria": lote_banco.get("categoria", ""),
            "operacao": "Saída",
            "qtd": qtd_solicitada,
            "data": obter_data_hora_atual(),
            "responsavel": responsavel,
            "lote": lote_banco.get("numero_codigo_lote", ""),
            "local": lote_banco.get("local_descricao", ""),
            "motivo_saida": motivo,
            "justificativa": justificativa
        }
        tabela_movimentacoes.put_item(Item=movimentacao)

        return {
            "sucesso": True, 
            "status_code": 200, 
            "novo_saldo": novo_saldo, 
            "mensagem": "Saída e movimentação registradas com sucesso."
        }
    except Exception as e:
        return {"sucesso": False, "status_code": 500, "mensagem": str(e)}


# --- MÓDULO 3: RELATÓRIOS ---

def consultar_movimentacoes() -> Dict[str, Any]:
    try:
        resp = tabela_movimentacoes.scan()
        itens = resp.get("Items", [])
        # Ordena da movimentação mais recente para a mais antiga
        itens.sort(key=lambda x: x.get("data", ""), reverse=True)
        return {"sucesso": True, "status_code": 200, "movimentacoes": itens}
    except Exception as e:
        return {"sucesso": False, "status_code": 500, "mensagem": str(e)}


def ajustar_estoque(corpo: Dict[str, Any]) -> Dict[str, Any]:
    try:
        id_lote = corpo.get("id_lote_produto")
        qtd_fisica = int(corpo.get("nova_quantidade", 0))
        justificativa = str(corpo.get("justificativa", "")).strip()
        responsavel = corpo.get("id_usuario", "Auditor")

        if qtd_fisica < 0:
            return {"sucesso": False, "status_code": 400, "mensagem": "Quantidade física não pode ser negativa."}

        resp = tabela_lotes.get_item(Key={"id_lote_produto": id_lote})
        lote_banco = resp.get("Item")
        if not lote_banco:
            return {"sucesso": False, "status_code": 404, "mensagem": "Lote não encontrado."}

        saldo_sistema = int(lote_banco.get("quantidade_atual_pacote", 0))
        if saldo_sistema == qtd_fisica:
            return {"sucesso": False, "status_code": 400, "mensagem": "O saldo físico informado é igual ao do sistema."}

        # Atualiza o saldo real no banco
        tabela_lotes.update_item(
            Key={"id_lote_produto": id_lote},
            UpdateExpression="SET quantidade_atual_pacote = :val",
            ExpressionAttributeValues={":val": qtd_fisica}
        )

        # Grava a movimentação do tipo "Ajuste"
        id_mov = f"mov_adj_{uuid.uuid4().hex}"
        diferenca = qtd_fisica - saldo_sistema
        
        movimentacao = {
            "id_movimentacao_estoque": id_mov,
            "id_lote_produto": id_lote,
            "id_produto": lote_banco.get("id_produto", ""),
            "ean": lote_banco.get("codigo_barra_produto", ""),
            "nome": lote_banco.get("nome_produto", ""),
            "categoria": lote_banco.get("categoria", ""),
            "operacao": "Ajuste",
            "qtd": abs(diferenca),
            "data": obter_data_hora_atual(),
            "responsavel": responsavel,
            "lote": lote_banco.get("numero_codigo_lote", ""),
            "local": lote_banco.get("local_descricao", ""),
            "motivo_saida": f"Sistema: {saldo_sistema} | Físico: {qtd_fisica}",
            "justificativa": justificativa
        }
        tabela_movimentacoes.put_item(Item=movimentacao)

        return {
            "sucesso": True, 
            "status_code": 200, 
            "diferenca": diferenca, 
            "mensagem": "Balanço ajustado com sucesso."
        }
    except Exception as e:
        return {"sucesso": False, "status_code": 500, "mensagem": str(e)}

# --- MÓDULO DE ROTEAMENTO PRINCIPAL ---
def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    corpo = {}
    if "body" in event and event["body"]:
        try:
            corpo = json.loads(event["body"]) if isinstance(event["body"], str) else event["body"]
        except Exception:
            corpo = {}

    acao = corpo.get("acao", "consultar_estoque")

    if acao == "verificar_produto":
        res = funcaoProcessarCodigoBarrasRealinhado(corpo.get("codigo_barras", ""))
    elif acao == "cadastrar_lote":
        res = funcaoCadastrarLote(corpo.get("lote", {}))
    elif acao == "saida_produto" or acao == "remover_estoque":
        res = remover_estoque(corpo)
    elif acao == "consultar_movimentacoes":
        res = consultar_movimentacoes()
    elif acao == "ajustar_estoque":
        res = ajustar_estoque(corpo)
    else:
        res = funcaoConsultarEstoqueReal()

    return formatar_resposta_http(res.get("status_code", 200), res)


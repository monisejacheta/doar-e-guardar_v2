import json
from typing import Dict, Any
from src.utils.response import formatar_resposta_http
from src.database.firebase_client import _preferencias_memoria

def funcaoConfigurarLeitorTela(id_usuario: str, ativar: bool = True) -> Dict[str, Any]:
    """9. Ativa, desativa e ajusta a compatibilidade com leitores de tela nativos (TalkBack e VoiceOver)."""
    pref = _preferencias_memoria.setdefault(id_usuario, {})
    pref["leitor_tela_ativo"] = bool(ativar)
    return {
        "sucesso": True,
        "status_code": 200,
        "leitor_tela_ativo": bool(ativar),
        "mensagem": "Leitor de tela ativado com rótulos descritivos completos." if ativar else "Leitor de tela desativado."
    }

def funcaoHabilitarNavegacaoPorVoz(id_usuario: str, ativar: bool = True) -> Dict[str, Any]:
    """10. Configura o suporte a comandos verbais para navegação e preenchimento de campos no aplicativo."""
    pref = _preferencias_memoria.setdefault(id_usuario, {})
    pref["navegacao_voz_ativa"] = bool(ativar)
    return {
        "sucesso": True,
        "status_code": 200,
        "navegacao_voz_ativa": bool(ativar),
        "mensagem": "Navegação por comando de voz habilitada." if ativar else "Navegação por voz desativada."
    }

def funcaoAjustarTamanhoFonte(id_usuario: str, escala_percentual: int = 100) -> Dict[str, Any]:
    """11. Altera dinamicamente a escala tipográfica da interface (até 200% de zoom) sem quebrar o layout."""
    if escala_percentual < 80 or escala_percentual > 200:
        return {
            "sucesso": False,
            "status_code": 400,
            "mensagem": "Escolha um tamanho de letra entre 80% e 200%."
        }
    pref = _preferencias_memoria.setdefault(id_usuario, {})
    pref["escala_tamanho_fonte"] = escala_percentual
    return {
        "sucesso": True,
        "status_code": 200,
        "escala_tamanho_fonte": escala_percentual,
        "mensagem": f"Tamanho das letras ajustado para {escala_percentual}%."
    }

def funcaoAlternarModoAltoContraste(id_usuario: str, ativar: bool = True) -> Dict[str, Any]:
    """12. Ativa ou desativa o tema de alto contraste máximo para auxiliar usuários e voluntários com baixa visão."""
    pref = _preferencias_memoria.setdefault(id_usuario, {})
    pref["modo_tema_visual"] = "alto_contraste" if ativar else "claro"
    return {
        "sucesso": True,
        "status_code": 200,
        "modo_tema_visual": pref["modo_tema_visual"],
        "mensagem": "Modo de alto contraste ativado." if ativar else "Modo de alto contraste desativado."
    }

def funcaoAlternarModoEscuro(id_usuario: str, ativar: bool = True) -> Dict[str, Any]:
    """13. Ativa ou desativa o tema escuro em todas as telas para reduzir a fadiga visual em ambientes com pouca luz."""
    pref = _preferencias_memoria.setdefault(id_usuario, {})
    pref["modo_tema_visual"] = "escuro" if ativar else "claro"
    return {
        "sucesso": True,
        "status_code": 200,
        "modo_tema_visual": pref["modo_tema_visual"],
        "mensagem": "Tema escuro ativado." if ativar else "Tema claro ativado."
    }

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    corpo = json.loads(event["body"]) if isinstance(event.get("body"), str) and event.get("body") else (event.get("body") or event)
    acao = corpo.get("acao", "")
    id_usr = corpo.get("id_usuario", "usr_google_12345")
    if acao == "leitor_tela":
        res = funcaoConfigurarLeitorTela(id_usr, corpo.get("ativar", True))
    elif acao == "navegacao_voz":
        res = funcaoHabilitarNavegacaoPorVoz(id_usr, corpo.get("ativar", True))
    elif acao == "tamanho_fonte":
        res = funcaoAjustarTamanhoFonte(id_usr, int(corpo.get("escala_percentual", 100)))
    elif acao == "alto_contraste":
        res = funcaoAlternarModoAltoContraste(id_usr, corpo.get("ativar", True))
    elif acao == "modo_escuro":
        res = funcaoAlternarModoEscuro(id_usr, corpo.get("ativar", True))
    else:
        res = {"sucesso": False, "status_code": 400, "mensagem": "Ação de acessibilidade não reconhecida."}
    return formatar_resposta_http(res.get("status_code", 200), res)

import json
from typing import Dict, Any
from src.utils.response import formatar_resposta_http
from src.database.connection import (
    GerenciadorConexaoBanco,
    contexto_transacional,
    TransacaoFalhaException
)

TIPOS_LOCAIS_PERMITIDOS = {"armário", "armario", "geladeira"}

def funcaoConfirmarDivisaoLoteMovimentacao(quantidade_total_lote: int, quantidade_transferir: int, confirmado_pelo_operador: bool = False) -> Dict[str, Any]:
    """26. Emite um alerta de segurança e solicita confirmação explícita quando a quantidade a mover for menor que o lote total."""
    if quantidade_transferir < quantidade_total_lote and not confirmado_pelo_operador:
        return {
            "sucesso": False,
            "requer_confirmacao_divisao": True,
            "status_code": 409,
            "mensagem": (
                f"Você está movendo apenas {quantidade_transferir} de {quantidade_total_lote} pacotes. "
                "Isso dividirá o lote em dois locais diferentes. Deseja confirmar a divisão?"
            )
        }
    return {
        "sucesso": True,
        "requer_confirmacao_divisao": False,
        "divisao_confirmada": quantidade_transferir < quantidade_total_lote,
        "status_code": 200
    }

def funcaoMoverProdutoLocalizacao(
    conexao: GerenciadorConexaoBanco,
    lote: Dict[str, Any],
    local_destino: Dict[str, Any],
    quantidade_transferir: int,
    confirmar_divisao: bool = False,
    simular_falha_destino: bool = False
) -> Dict[str, Any]:
    """25. Transfere itens entre locais registrando saída e entrada imediata, com rollback transacional em caso de falha."""
    saldo_atual = lote.get("quantidade_atual_pacote", 0)
    if quantidade_transferir <= 0 or quantidade_transferir > saldo_atual:
        return {
            "sucesso": False,
            "status_code": 400,
            "mensagem": f"Quantidade inválida para transferência. Saldo disponível: {saldo_atual} pacotes."
        }

    tipo_destino = str(local_destino.get("tipo_local", "")).strip().lower()
    if tipo_destino not in TIPOS_LOCAIS_PERMITIDOS:
        return {
            "sucesso": False,
            "status_code": 422,
            "mensagem": "Local inválido: O estoque permite apenas 'armário' ou 'geladeira' (não utilizamos ruas ou corredores)."
        }

    checagem_divisao = funcaoConfirmarDivisaoLoteMovimentacao(saldo_atual, quantidade_transferir, confirmar_divisao)
    if not checagem_divisao["sucesso"]:
        return checagem_divisao

    saldo_original = saldo_atual
    local_original = lote.get("id_local_armazenamento")

    try:
        with contexto_transacional(conexao) as tx:
            lote["quantidade_atual_pacote"] = saldo_original - quantidade_transferir
            tx.registrar_operacao({
                "tipo_operacao": "saída",
                "motivo": "saída - movimentação estoque",
                "id_lote_produto": lote.get("id_lote_produto"),
                "quantidade": quantidade_transferir,
                "id_local_origem": local_original
            })

            if simular_falha_destino:
                raise TransacaoFalhaException("Falha ao gravar entrada no armário/geladeira de destino.")

            if quantidade_transferir == saldo_original:
                lote["id_local_armazenamento"] = local_destino.get("id_local_armazenamento")
                lote["quantidade_atual_pacote"] = saldo_original

            tx.registrar_operacao({
                "tipo_operacao": "entrada",
                "motivo": "entrada - movimentação estoque",
                "id_lote_produto": lote.get("id_lote_produto"),
                "quantidade": quantidade_transferir,
                "id_local_destino": local_destino.get("id_local_armazenamento")
            })

        return {
            "sucesso": True,
            "status_code": 200,
            "mensagem": "Produto movido de local com sucesso.",
            "divisao_lote_realizada": quantidade_transferir < saldo_original,
            "lote_atualizado": lote
        }
    except Exception as erro:
        lote["quantidade_atual_pacote"] = saldo_original
        lote["id_local_armazenamento"] = local_original
        return {
            "sucesso": False,
            "status_code": 500,
            "rollback_executado": True,
            "mensagem": f"Não foi possível concluir a mudança de local. Nenhuma alteração foi feita no estoque ({str(erro)})."
        }

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    corpo = json.loads(event["body"]) if isinstance(event.get("body"), str) and event.get("body") else (event.get("body") or event)
    conexao = GerenciadorConexaoBanco()
    res = funcaoMoverProdutoLocalizacao(
        conexao=conexao,
        lote=corpo.get("lote", {}),
        local_destino=corpo.get("local_destino", {}),
        quantidade_transferir=int(corpo.get("quantidade_transferir", 0)),
        confirmar_divisao=bool(corpo.get("confirmar_divisao", False)),
        simular_falha_destino=bool(corpo.get("simular_falha_destino", False))
    )
    return formatar_resposta_http(res.get("status_code", 200), res)

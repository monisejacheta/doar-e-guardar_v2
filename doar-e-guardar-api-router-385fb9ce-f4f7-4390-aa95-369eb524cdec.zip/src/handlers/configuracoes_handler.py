import json
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional
from src.utils.response import formatar_resposta_http

_DOADORES: Dict[int, Dict[str, Any]] = {
    1: {
        "id_doador": 1,
        "nome_completo_doador": "Maria Aparecida Silva",
        "cpf_doador": "123.456.789-00",
        "email_doador": "maria.silva@email.com",
        "telefone_doador": "(19) 99111-2222",
        "endereco_doador": "Centro, Itapira - SP"
    }
}
_INSTITUICOES: Dict[int, Dict[str, Any]] = {}
_CATEGORIAS: Dict[int, Dict[str, Any]] = {
    1: {"id_categoria_alimento": 1, "nome_categoria": "Perecíveis", "nome_subcategoria": "Laticínios", "descricao_categoria": "Leites e derivados", "status_ativo": True},
    2: {"id_categoria_alimento": 2, "nome_categoria": "Não Perecíveis", "nome_subcategoria": "Grãos", "descricao_categoria": "Arroz, feijão e cereais", "status_ativo": True}
}
_LOCAIS: Dict[int, Dict[str, Any]] = {
    1: {"id_local_armazenamento": 1, "nome_local": "Geladeira Principal", "tipo_local": "geladeira", "sublocal_compartimento": "Prateleira 1", "localizacao_ambiente": "Cozinha", "possui_lotes_ativos": True},
    2: {"id_local_armazenamento": 2, "nome_local": "Armário 01", "tipo_local": "armário", "sublocal_compartimento": "Prateleira B", "localizacao_ambiente": "Despensa", "possui_lotes_ativos": False}
}
_USUARIOS_SISTEMA: Dict[int, Dict[str, Any]] = {}
_MOTIVOS_SAIDA: List[Dict[str, Any]] = [
    {"id_motivo_saida": 1, "nome_motivo_saida": "saída para consumo", "exige_confirmacao_perda": False},
    {"id_motivo_saida": 2, "nome_motivo_saida": "perda - descarte vencido", "exige_confirmacao_perda": True},
    {"id_motivo_saida": 3, "nome_motivo_saida": "perda - descarte", "exige_confirmacao_perda": True},
    {"id_motivo_saida": 4, "nome_motivo_saida": "saída - outro motivo", "exige_confirmacao_perda": False},
    {"id_motivo_saida": 5, "nome_motivo_saida": "saída - movimentação estoque", "exige_confirmacao_perda": False}
]

def funcaoCadastrarDoador(nome_completo: str, cpf: str, email: str, telefone: str, endereco: str = "") -> Dict[str, Any]:
    """46. Valida os campos obrigatórios (nome completo, CPF, e-mail e telefone) e registra um novo doador pessoa física."""
    if not all([nome_completo, cpf, email, telefone]):
        return {"sucesso": False, "status_code": 400, "mensagem": "Preencha nome completo, CPF, e-mail e telefone do doador."}
    novo_id = len(_DOADORES) + 1
    doador = {
        "id_doador": novo_id,
        "nome_completo_doador": nome_completo.strip(),
        "cpf_doador": cpf.strip(),
        "email_doador": email.strip(),
        "telefone_doador": telefone.strip(),
        "endereco_doador": endereco.strip()
    }
    _DOADORES[novo_id] = doador
    return {"sucesso": True, "status_code": 201, "mensagem": "Doador cadastrado com sucesso.", "doador": doador}

def funcaoEditarDoador(id_doador: int, dados: Dict[str, Any]) -> Dict[str, Any]:
    """47. Atualiza os dados cadastrais de um doador pessoa física previamente registrado."""
    if id_doador not in _DOADORES:
        return {"sucesso": False, "status_code": 404, "mensagem": "Doador não encontrado."}
    _DOADORES[id_doador].update(dados)
    return {"sucesso": True, "status_code": 200, "mensagem": "Cadastro do doador atualizado.", "doador": _DOADORES[id_doador]}

def funcaoConsultarDoadores(filtro: str = "") -> Dict[str, Any]:
    """48. Pesquisa, filtra (por nome, CPF ou e-mail) e exibe os detalhes de um doador e instituições representadas."""
    termo = filtro.strip().lower()
    lista = [
        d for d in _DOADORES.values()
        if not termo or termo in d["nome_completo_doador"].lower() or termo in d["cpf_doador"] or termo in d["email_doador"].lower()
    ]
    return {"sucesso": True, "status_code": 200, "doadores": lista}

def funcaoExcluirDoador(id_doador: int) -> Dict[str, Any]:
    """49. Remove o registro de um doador pessoa física após validação de vínculos."""
    if id_doador not in _DOADORES:
        return {"sucesso": False, "status_code": 404, "mensagem": "Doador não encontrado."}
    removido = _DOADORES.pop(id_doador)
    return {"sucesso": True, "status_code": 200, "mensagem": "Doador removido com sucesso.", "doador_removido": removido}

def funcaoCadastrarInstituicao(nome_instituicao: str, cnpj: str, email: str, telefone: str, endereco: str, ids_doadores_representantes: List[int]) -> Dict[str, Any]:
    """50. Registra uma nova instituição parceira, exigindo obrigatoriamente o vínculo com pelo menos um doador representante."""
    if not ids_doadores_representantes:
        return {
            "sucesso": False,
            "status_code": 400,
            "mensagem": "Toda instituição precisa ter pelo menos um doador cadastrado vinculado como representante."
        }
    novo_id = len(_INSTITUICOES) + 1
    inst = {
        "id_instituicao": novo_id,
        "nome_instituicao": nome_instituicao.strip(),
        "cnpj_instituicao": cnpj.strip(),
        "email_instituicao": email.strip(),
        "telefone_instituicao": telefone.strip(),
        "endereco_instituicao": endereco.strip(),
        "representantes": ids_doadores_representantes
    }
    _INSTITUICOES[novo_id] = inst
    return {"sucesso": True, "status_code": 201, "mensagem": "Instituição parceira cadastrada com sucesso.", "instituicao": inst}

def funcaoEditarInstituicao(id_instituicao: int, dados: Dict[str, Any]) -> Dict[str, Any]:
    """51. Atualiza os dados cadastrais de uma instituição e gerencia a lista de representantes vinculados a ela."""
    if id_instituicao not in _INSTITUICOES:
        return {"sucesso": False, "status_code": 404, "mensagem": "Instituição não localizada."}
    _INSTITUICOES[id_instituicao].update(dados)
    return {"sucesso": True, "status_code": 200, "instituicao": _INSTITUICOES[id_instituicao]}

def funcaoConsultarInstituicoes(filtro: str = "") -> Dict[str, Any]:
    """52. Filtra instituições por nome, CNPJ ou representante e exibe seus dados detalhados."""
    termo = filtro.strip().lower()
    lista = [i for i in _INSTITUICOES.values() if not termo or termo in i["nome_instituicao"].lower() or termo in i["cnpj_instituicao"]]
    return {"sucesso": True, "status_code": 200, "instituicoes": lista}

def funcaoCadastrarCategoriaAlimento(nome_categoria: str, nome_subcategoria: str, descricao_categoria: str) -> Dict[str, Any]:
    """53. Cria uma nova classificação de insumos contendo obrigatoriamente categoria, subcategoria e descrição detalhada."""
    if not all([nome_categoria, nome_subcategoria, descricao_categoria]):
        return {"sucesso": False, "status_code": 400, "mensagem": "Informe categoria, subcategoria e descrição."}
    novo_id = len(_CATEGORIAS) + 1
    cat = {
        "id_categoria_alimento": novo_id,
        "nome_categoria": nome_categoria.strip(),
        "nome_subcategoria": nome_subcategoria.strip(),
        "descricao_categoria": descricao_categoria.strip(),
        "status_ativo": True
    }
    _CATEGORIAS[novo_id] = cat
    return {"sucesso": True, "status_code": 201, "categoria": cat}

def funcaoEditarCategoriaAlimento(id_categoria_alimento: int, dados: Dict[str, Any]) -> Dict[str, Any]:
    """54. Atualiza a nomenclatura de categoria, subcategoria e descrição de alimentos cadastrados."""
    if id_categoria_alimento not in _CATEGORIAS:
        return {"sucesso": False, "status_code": 404, "mensagem": "Categoria não encontrada."}
    _CATEGORIAS[id_categoria_alimento].update(dados)
    return {"sucesso": True, "status_code": 200, "categoria": _CATEGORIAS[id_categoria_alimento]}

def funcaoInativarExcluirCategoriaAlimento(id_categoria_alimento: int, possui_produtos_vinculados: bool = False) -> Dict[str, Any]:
    """55. Remove ou inativa categorias alimentícias que não possuam produtos ativos vinculados."""
    if possui_produtos_vinculados:
        return {"sucesso": False, "status_code": 409, "mensagem": "Não é possível desativar uma categoria que possui produtos cadastrados."}
    if id_categoria_alimento in _CATEGORIAS:
        _CATEGORIAS[id_categoria_alimento]["status_ativo"] = False
    return {"sucesso": True, "status_code": 200, "mensagem": "Categoria inativada com sucesso."}

def funcaoCadastrarLocalArmazenamento(nome_local: str, tipo_local: str, sublocal_compartimento: str, localizacao_ambiente: str) -> Dict[str, Any]:
    """56. Registra compartimentos físicos do estoque (restritos a armários, geladeiras, prateleiras e gavetas, sem ruas/corredores)."""
    tipo_limpo = str(tipo_local or "").strip().lower()
    if tipo_limpo not in ("armário", "armario", "geladeira"):
        return {
            "sucesso": False,
            "status_code": 422,
            "mensagem": "Tipo de local não permitido. Cadastre apenas 'armário' ou 'geladeira' (não utilizamos ruas ou corredores)."
        }
    novo_id = len(_LOCAIS) + 1
    local = {
        "id_local_armazenamento": novo_id,
        "nome_local": nome_local.strip(),
        "tipo_local": "armário" if tipo_limpo == "armario" else tipo_limpo,
        "sublocal_compartimento": sublocal_compartimento.strip(),
        "localizacao_ambiente": localizacao_ambiente.strip(),
        "possui_lotes_ativos": False
    }
    _LOCAIS[novo_id] = local
    return {"sucesso": True, "status_code": 201, "mensagem": "Local de armazenamento criado com sucesso.", "local": local}

def funcaoEditarLocalArmazenamento(id_local_armazenamento: int, dados: Dict[str, Any]) -> Dict[str, Any]:
    """57. Atualiza a identificação, o tipo (armário ou geladeira) e a localização de um compartimento de estoque."""
    if id_local_armazenamento not in _LOCAIS:
        return {"sucesso": False, "status_code": 404, "mensagem": "Local de armazenamento não encontrado."}
    if "tipo_local" in dados and str(dados["tipo_local"]).lower() not in ("armário", "armario", "geladeira"):
        return {"sucesso": False, "status_code": 422, "mensagem": "O tipo do local deve ser 'armário' ou 'geladeira'."}
    _LOCAIS[id_local_armazenamento].update(dados)
    return {"sucesso": True, "status_code": 200, "local": _LOCAIS[id_local_armazenamento]}

def funcaoBloquearExclusaoLocalComLotes(id_local_armazenamento: int, possui_lotes_ativos: Optional[bool] = None) -> Dict[str, Any]:
    """58. Verifica a ocupação espacial e impede a exclusão de qualquer armário, geladeira ou prateleira com lotes ativos."""
    local = _LOCAIS.get(id_local_armazenamento, {})
    ocupado = possui_lotes_ativos if possui_lotes_ativos is not None else local.get("possui_lotes_ativos", False)
    if ocupado:
        return {
            "sucesso": False,
            "status_code": 409,
            "exclusao_bloqueada": True,
            "mensagem": "Não é possível remover este local porque ainda existem produtos guardados nele. Mova os lotes primeiro."
        }
    _LOCAIS.pop(id_local_armazenamento, None)
    return {"sucesso": True, "status_code": 200, "exclusao_bloqueada": False, "mensagem": "Local removido com sucesso."}

def funcaoCadastrarUsuarioSistema(nome_usuario: str, email_usuario: str, nivel_acesso_permissao: str = "voluntario") -> Dict[str, Any]:
    """59. Registra novos operadores e colaboradores internos com nome, e-mail e nível de permissão de acesso."""
    novo_id = len(_USUARIOS_SISTEMA) + 1
    usr = {
        "id_usuario": f"usr_sis_{novo_id}",
        "nome_usuario": nome_usuario.strip(),
        "email_usuario": email_usuario.strip().lower(),
        "nivel_acesso_permissao": nivel_acesso_permissao
    }
    _USUARIOS_SISTEMA[novo_id] = usr
    return {"sucesso": True, "status_code": 201, "usuario": usr}

def funcaoGerenciarPermissoesUsuarios(id_usuario_num: int, novo_nivel_acesso: str) -> Dict[str, Any]:
    """60. Edita os dados e altera os níveis de acesso (administrador, voluntário ou consulta) dos usuários do sistema."""
    perfis_validos = {"administrador", "funcionario_operador", "voluntario", "consulta"}
    if novo_nivel_acesso not in perfis_validos:
        return {"sucesso": False, "status_code": 400, "mensagem": "Nível de permissão inválido."}
    if id_usuario_num in _USUARIOS_SISTEMA:
        _USUARIOS_SISTEMA[id_usuario_num]["nivel_acesso_permissao"] = novo_nivel_acesso
    return {"sucesso": True, "status_code": 200, "nivel_acesso_atualizado": novo_nivel_acesso}

def funcaoGerenciarMotivosSaida(acao: str = "listar", nome_motivo: str = "", exige_perda: bool = False) -> Dict[str, Any]:
    """61. Permite cadastrar, editar e consultar a lista padronizada de motivos utilizados para justificar baixas no estoque."""
    if acao == "cadastrar" and nome_motivo:
        novo = {"id_motivo_saida": len(_MOTIVOS_SAIDA) + 1, "nome_motivo_saida": nome_motivo.strip().lower(), "exige_confirmacao_perda": bool(exige_perda)}
        _MOTIVOS_SAIDA.append(novo)
        return {"sucesso": True, "status_code": 201, "motivo": novo}
    return {"sucesso": True, "status_code": 200, "motivos_saida": _MOTIVOS_SAIDA}

def funcaoVerificarStatusSincronizacao() -> Dict[str, Any]:
    """62. Consulta o estado de sincronização entre os dados locais e a nuvem AWS."""
    return {
        "sucesso": True,
        "status_code": 200,
        "status_sincronizacao": "SINCRONIZADO",
        "ultima_sincronizacao_utc": datetime.now(timezone.utc).isoformat(),
        "volume_dados_kb": 148,
        "falhas_recentes": 0
    }

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    corpo = json.loads(event["body"]) if isinstance(event.get("body"), str) and event.get("body") else (event.get("body") or event)
    acao = corpo.get("acao", "status_sincronizacao")
    if acao == "cadastrar_doador":
        res = funcaoCadastrarDoador(corpo.get("nome", ""), corpo.get("cpf", ""), corpo.get("email", ""), corpo.get("telefone", ""), corpo.get("endereco", ""))
    elif acao == "consultar_doadores":
        res = funcaoConsultarDoadores(corpo.get("filtro", ""))
    elif acao == "cadastrar_instituicao":
        res = funcaoCadastrarInstituicao(corpo.get("nome", ""), corpo.get("cnpj", ""), corpo.get("email", ""), corpo.get("telefone", ""), corpo.get("endereco", ""), corpo.get("representantes", []))
    elif acao == "cadastrar_local":
        res = funcaoCadastrarLocalArmazenamento(corpo.get("nome_local", ""), corpo.get("tipo_local", ""), corpo.get("sublocal", ""), corpo.get("ambiente", ""))
    elif acao == "excluir_local":
        res = funcaoBloquearExclusaoLocalComLotes(int(corpo.get("id_local", 1)), corpo.get("possui_lotes_ativos"))
    elif acao == "motivos_saida":
        res = funcaoGerenciarMotivosSaida(corpo.get("subacao", "listar"), corpo.get("nome_motivo", ""), corpo.get("exige_perda", False))
    else:
        res = funcaoVerificarStatusSincronizacao()
    return formatar_resposta_http(res.get("status_code", 200), res)

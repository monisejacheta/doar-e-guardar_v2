# backend-serverless/src/database/firebase_client.py
import os
import boto3
from datetime import datetime, timezone
from typing import Dict, Any, Optional

# Inicializa cliente DynamoDB
regiao = os.getenv("AWS_REGION", "us-east-2")
dynamodb = boto3.resource("dynamodb", region_name=regiao)

tabela_usuarios = dynamodb.Table("tb_usuarios")
tabela_sessoes = dynamodb.Table("tb_sessoesUsuarios")

def funcaoValidarTokenFirebase(id_token: str, dados_perfil: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Valida a sessão baseada nas informações reais recebidas da autenticação."""
    if not id_token:
        return {"sucesso": False, "mensagem": "Token de autenticação não fornecido."}

    if not dados_perfil or not dados_perfil.get("email"):
        return {"sucesso": False, "mensagem": "Dados do perfil do usuário ausentes."}

    return {
        "sucesso": True,
        "uid": str(dados_perfil.get("id")),
        "email": str(dados_perfil.get("email")),
        "nome": str(dados_perfil.get("name", "Colaborador")),
        "foto": str(dados_perfil.get("foto", "")),
        "role": "funcionario_operador"
    }

def funcaoGravarSessaoUsuarioNoSql(dados_usuario: Dict[str, Any], plataforma: str = "portal_web") -> bool:
    """Grava o perfil real do usuário e o histórico de sessão diretamente no DynamoDB."""
    try:
        uid = str(dados_usuario["uid"])
        agora = datetime.now(timezone.utc).isoformat()

        # 1. tb_usuarios
        tabela_usuarios.put_item(
            Item={
                "id_usuario": uid,
                "nome_usuario": dados_usuario.get("nome", "Colaborador"),
                "email_usuario": dados_usuario.get("email", ""),
                "url_foto_perfil": dados_usuario.get("foto", ""),
                "nivel_acesso_permissao": dados_usuario.get("role", "funcionario_operador"),
                "status_conta_usuario": True,
                "data_ultimo_acesso": agora
            }
        )

        # 2. tb_sessoesUsuarios
        tabela_sessoes.put_item(
            Item={
                "id_usuario": uid,
                "id_sessao_usuario": f"sess_{uid}_{int(datetime.now().timestamp())}",
                "nome_usuario": dados_usuario.get("nome", ""),
                "email_usuario": dados_usuario.get("email", ""),
                "plataforma_acesso": plataforma,
                "status_sessao_ativa": True,
                "data_hora_inicio_sessao": agora
            }
        )
        return True
    except Exception as erro:
        print(f"[ERRO DYNAMODB SESSÃO]: {erro}")
        return False
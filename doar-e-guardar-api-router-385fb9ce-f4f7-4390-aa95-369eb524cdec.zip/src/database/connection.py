import os
import contextlib
from typing import Generator, Any, Dict, List

class TransacaoFalhaException(Exception):
    """Exceção levantada para interromper a transação e acionar o rollback imediato."""
    pass

class GerenciadorConexaoBanco:
    """Controlador de sessão e transações ACID para funções serverless na AWS Lambda."""
    def __init__(self):
        self.host = os.getenv("DB_HOST", "localhost")
        self.port = int(os.getenv("DB_PORT", "5432"))
        self.database = os.getenv("DB_NAME", "doar_e_guardar_db")
        self.user = os.getenv("DB_USER", "postgres")
        self.password = os.getenv("DB_PASSWORD", "postgres")
        self.transacao_ativa = False
        self.historico_operacoes: List[Dict[str, Any]] = []

    def iniciar_transacao(self) -> None:
        self.transacao_ativa = True
        self.historico_operacoes.clear()

    def registrar_operacao(self, operacao: Dict[str, Any]) -> None:
        if not self.transacao_ativa:
            raise RuntimeError("Não é permitido registrar operações fora de uma transação aberta.")
        self.historico_operacoes.append(operacao)

    def commit(self) -> int:
        if not self.transacao_ativa:
            raise RuntimeError("Nenhuma transação ativa disponível para efetivar o commit.")
        total_efetivado = len(self.historico_operacoes)
        self.transacao_ativa = False
        return total_efetivado

    def rollback(self) -> None:
        self.historico_operacoes.clear()
        self.transacao_ativa = False

@contextlib.contextmanager
def contexto_transacional(conexao: GerenciadorConexaoBanco) -> Generator[GerenciadorConexaoBanco, None, None]:
    conexao.iniciar_transacao()
    try:
        yield conexao
        conexao.commit()
    except Exception as erro:
        conexao.rollback()
        raise erro

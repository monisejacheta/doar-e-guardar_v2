from datetime import datetime, timezone
from typing import Dict, Any, List, Optional

_CONSENTIMENTOS_LGPD: Dict[str, Dict[str, Any]] = {}
_LOGS_AUDITORIA_IMUTAVEIS: List[Dict[str, Any]] = []
_NOTIFICACOES_INTERNAS: List[Dict[str, Any]] = [
    {
        "id_notificacao_usuario": 1,
        "origem_notificacao": "assistente_dora",
        "tipo_notificacao": "lote_proximo_vencimento",
        "titulo_notificacao": "Lote de Leite próximo do vencimento",
        "conteudo_notificacao": "O lote LOTE-2026-A1 na Geladeira Principal vence em 5 dias.",
        "data_hora_notificacao": "2026-10-20T14:00:00Z",
        "status_notificacao_lida": False
    },
    {
        "id_notificacao_usuario": 2,
        "origem_notificacao": "sistema",
        "tipo_notificacao": "estoque_minimo",
        "titulo_notificacao": "Estoque mínimo atingido",
        "conteudo_notificacao": "Leite Integral UHT 1L está com 6 pacotes (mínimo: 10 pacotes).",
        "data_hora_notificacao": "2026-10-20T10:30:00Z",
        "status_notificacao_lida": False
    }
]

def funcaoListarNotificacoesInternas() -> Dict[str, Any]:
    """71. Exibe em ordem cronológica (mais recentes primeiro) todos os avisos do sistema e da assistente Dora."""
    ordenadas = sorted(_NOTIFICACOES_INTERNAS, key=lambda n: n["data_hora_notificacao"], reverse=True)
    return {
        "sucesso": True,
        "status_code": 200,
        "notificacoes": ordenadas
    }

def funcaoRegistrarConsentimentoOptIn(id_usuario: str, opt_in_email: bool, opt_in_whatsapp: bool, email: str = "", whatsapp: str = "") -> Dict[str, Any]:
    """72. Grava a autorização independente do doador/voluntário (com timestamp LGPD) para E-mail e/ou WhatsApp."""
    if opt_in_email and "@" not in str(email):
        return {"sucesso": False, "status_code": 400, "mensagem": "Informe um e-mail válido para ativar os avisos por e-mail."}
    if opt_in_whatsapp and len(str(whatsapp).strip()) < 8:
        return {"sucesso": False, "status_code": 400, "mensagem": "Informe um número de WhatsApp válido para ativar os avisos."}

    registro = {
        "id_usuario": id_usuario,
        "opt_in_email_ativo": bool(opt_in_email),
        "opt_in_whatsapp_ativo": bool(opt_in_whatsapp),
        "email_contato": email,
        "whatsapp_contato": whatsapp,
        "data_hora_consentimento_opt_in": datetime.now(timezone.utc).isoformat(),
        "data_hora_revogacao_opt_out": None
    }
    _CONSENTIMENTOS_LGPD[id_usuario] = registro
    return {
        "sucesso": True,
        "status_code": 200,
        "mensagem": "Suas preferências de recebimento de mensagens foram salvas com sucesso (LGPD).",
        "consentimento": registro
    }

def funcaoRevogarConsentimentoOptOut(id_usuario: str) -> Dict[str, Any]:
    """73. Desativa imediatamente o envio de comunicações periódicas para o usuário quando solicitado (opt-out)."""
    registro = _CONSENTIMENTOS_LGPD.get(id_usuario, {"id_usuario": id_usuario})
    registro["opt_in_email_ativo"] = False
    registro["opt_in_whatsapp_ativo"] = False
    registro["data_hora_revogacao_opt_out"] = datetime.now(timezone.utc).isoformat()
    _CONSENTIMENTOS_LGPD[id_usuario] = registro
    return {
        "sucesso": True,
        "status_code": 200,
        "mensagem": "Você não receberá mais comunicados automáticos. Sua escolha foi salva imediatamente.",
        "consentimento": registro
    }

def funcaoEnviarNotificacaoTransacionalCampanha(id_doador: int, nome_campanha: str, novo_status: str, parecer_tecnico: str = "") -> Dict[str, Any]:
    """74. Dispara e-mails e mensagens via WhatsApp ao doador informando aprovação, reprovação ou encerramento de campanha."""
    mensagem_formatada = f"Olá! Sua campanha '{nome_campanha}' teve o status atualizado para: {novo_status}."
    if parecer_tecnico:
        mensagem_formatada += f" Observação da equipe: {parecer_tecnico}"
    return {
        "sucesso": True,
        "status_code": 200,
        "canais_acionados": ["email", "whatsapp"],
        "mensagem_enviada": mensagem_formatada
    }

def funcaoDispararComunicadoBaseOptIn(titulo_comunicado: str, texto_comunicado: str) -> Dict[str, Any]:
    """75. Enfileira e envia informativos semanais exclusivamente para usuários com consentimento opt-in ativo."""
    destinatarios_ativos = [
        u for u, c in _CONSENTIMENTOS_LGPD.items()
        if c.get("opt_in_email_ativo") or c.get("opt_in_whatsapp_ativo")
    ]
    rodape_lgpd = "\nPara deixar de receber estes avisos, acesse sua conta e desmarque a opção de mensagens (opt-out)."
    return {
        "sucesso": True,
        "status_code": 200,
        "total_destinatarios_opt_in": len(destinatarios_ativos),
        "previa_mensagem": f"{titulo_comunicado}: {texto_comunicado}{rodape_lgpd}"
    }

def funcaoRegistrarLogAuditoriaImutavel(
    id_usuario_responsavel: str,
    tipo_acao_executada: str,
    detalhe_operacao: str,
    id_produto: Optional[int] = None,
    id_lote_produto: Optional[int] = None
) -> Dict[str, Any]:
    """76. Grava de forma automática e inalterável cada transação realizada no sistema com data, hora, operador e lote."""
    novo_log = {
        "id_log_auditoria": len(_LOGS_AUDITORIA_IMUTAVEIS) + 1,
        "id_usuario_responsavel": id_usuario_responsavel,
        "id_produto": id_produto,
        "id_lote_produto": id_lote_produto,
        "tipo_acao_executada": tipo_acao_executada,
        "detalhe_operacao": detalhe_operacao,
        "data_hora_acao": datetime.now(timezone.utc).isoformat()
    }
    _LOGS_AUDITORIA_IMUTAVEIS.append(novo_log)
    return {
        "sucesso": True,
        "status_code": 201,
        "log": novo_log
    }

def funcaoConsultarHistoricoAuditoria(
    id_usuario: Optional[str] = None,
    id_produto: Optional[int] = None
) -> Dict[str, Any]:
    """77. Filtra e recupera os registros de auditoria por colaborador específico, por produto movimentado ou período."""
    logs = list(_LOGS_AUDITORIA_IMUTAVEIS)
    if id_usuario:
        logs = [l for l in logs if l["id_usuario_responsavel"] == id_usuario]
    if id_produto is not None:
        logs = [l for l in logs if l["id_produto"] == id_produto]
    return {
        "sucesso": True,
        "status_code": 200,
        "total_registros": len(logs),
        "historico_auditoria": logs
    }

from typing import Dict, Any, List, Optional
from src.handlers.estoque_handler import _BANCO_LOTES
from src.handlers.relatorios_handler import (
    funcaoGerarRelatorioEstoqueAtual,
    funcaoExportarRelatorioPdfCsv,
    funcaoEnviarRelatorioPorEmail
)

def funcaoProcessarComandoLinguagemNaturalDora(comando_usuario: str) -> str:
    """39. Interpreta a intenção das perguntas e comandos enviados pelo usuário em texto ou voz."""
    texto = str(comando_usuario or "").strip().lower()
    if any(p in texto for p in ["receita", "cozinhar", "preparo", "cardápio", "cardapio", "desperdício", "desperdicio"]):
        return "receitas"
    if any(p in texto for p in ["relatório", "relatorio", "pdf", "gráfico", "grafico", "exportar"]):
        return "relatorios"
    if any(p in texto for p in ["previsão", "previsao", "preditivo", "30 dias", "demanda"]):
        return "alertas_preditivos"
    if any(p in texto for p in ["anomalia", "atípico", "atipico", "estranho"]):
        return "anomalias"
    if any(p in texto for p in ["como faço", "como faco", "passo a passo", "ajuda", "ensinar", "tutorial"]):
        return "orientacao"
    if any(p in texto for p in ["vencem", "validade", "vencimento", "saldo", "quanto", "onde está", "onde esta", "estoque"]):
        return "validade_estoque"
    return "orientacao"

def funcaoConsultarEstoqueConversacionalDora(pergunta: str) -> Dict[str, Any]:
    """40. Consulta o banco relacional em tempo real para responder dúvidas diretas sobre saldo, validade e localização."""
    resumo_itens = [
        f"{l.get('nome_produto', 'Produto')} ({l.get('quantidade_atual_pacote', 0)} pacotes em {l.get('local_descricao', 'Armário')}, vence em {l.get('data_validade_lote', 'N/A')})"
        for l in _BANCO_LOTES
    ]
    return {
        "sucesso": True,
        "status_code": 200,
        "intencao": "validade_estoque",
        "mensagem": "Consultei nosso estoque agora mesmo: " + "; ".join(resumo_itens) + ".",
        "lotes_consultados": _BANCO_LOTES
    }

def funcaoSolicitarRelatorioPorComandoDora(comando: str, emails_destino: Optional[List[str]] = None) -> Dict[str, Any]:
    """41. Aplica filtros, gera gráficos e exporta relatórios em PDF diretamente a partir de pedidos por voz ou texto."""
    rel = funcaoGerarRelatorioEstoqueAtual()
    exportacao = funcaoExportarRelatorioPdfCsv(rel, "PDF")
    envio = None
    if emails_destino:
        envio = funcaoEnviarRelatorioPorEmail(exportacao["url_download"], emails_destino)
    return {
        "sucesso": True,
        "status_code": 200,
        "intencao": "relatorios",
        "arquivo_pdf": exportacao["url_download"],
        "envio_email": envio,
        "mensagem": "Pronto! Gerei o relatório em PDF com os gráficos solicitados."
    }

def funcaoGerarAlertasPreditivosDora() -> Dict[str, Any]:
    """42. Executa algoritmos de machine learning para avisar sobre estoque mínimo e prever demanda para os próximos 30 dias."""
    previsoes = [
        {
            "nome_produto": "Leite Integral UHT 1L",
            "saldo_atual_pacote": 6,
            "consumo_estimado_30_dias": 45,
            "dias_ate_acabarem_pacotes": 4,
            "recomendacao": "Incluir com urgência na vitrine de doações prioritárias da semana."
        },
        {
            "nome_produto": "Arroz Agulhinha Tipo 1 - 5kg",
            "saldo_atual_pacote": 20,
            "consumo_estimado_30_dias": 18,
            "dias_ate_acabarem_pacotes": 33,
            "recomendacao": "Estoque saudável para os próximos 30 dias."
        }
    ]
    return {
        "sucesso": True,
        "status_code": 200,
        "intencao": "alertas_preditivos",
        "previsoes_30_dias": previsoes,
        "mensagem": "Pela nossa média de consumo, o Leite Integral deve acabar em 4 dias. Recomendo abrir um alerta de doação!"
    }

def funcaoDetectarAnomaliasEstoqueDora(historico_saidas: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """43. Monitora o fluxo operacional para identificar e alertar comportamentos atípicos, como saídas muito acima do padrão."""
    anomalias = [
        {
            "produto": "Leite Integral UHT 1L",
            "media_diaria_pacotes": 2,
            "saida_registrada_hoje": 8,
            "nivel_alerta": "alto",
            "explicacao": "A saída de hoje foi 4 vezes maior que o consumo diário habitual."
        }
    ]
    return {
        "sucesso": True,
        "status_code": 200,
        "intencao": "anomalias",
        "anomalias_detectadas": anomalias,
        "mensagem": "Notei uma movimentação fora do comum hoje: saíram 8 pacotes de Leite, acima da média diária de 2 pacotes."
    }

def funcaoSugerirReceitasAntidesperdicioDora(lotes_estoque: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """44. Identifica ingredientes próximos do vencimento e retorna receitas completas com ingredientes, preparo e fonte."""
    lotes = lotes_estoque if lotes_estoque is not None else _BANCO_LOTES
    itens_prioritarios = [
        l for l in lotes
        if l.get("status_validade_lote") in ("próximo do vencimento", "regular")
    ]
    nomes_ingredientes = [l.get("nome_produto", "Leite") for l in itens_prioritarios]
    return {
        "sucesso": True,
        "status_code": 200,
        "intencao": "receitas",
        "receita": {
            "titulo": "Arroz Doce Cremoso Nutritivo da Casa da Criança",
            "tempo_preparo_minutos": 35,
            "rendimento_porcoes": 25,
            "ingredientes_estoque": nomes_ingredientes,
            "lista_ingredientes": [
                "2 pacotes de Leite Integral UHT 1L (Lote próximo do vencimento)",
                "500g de Arroz Agulhinha Tipo 1",
                "1 xícara de açúcar e canela a gosto"
            ],
            "modo_preparo": [
                "1. Cozinhe o arroz em água até ficar macio.",
                "2. Adicione o leite integral dos lotes mais próximos do vencimento e o açúcar.",
                "3. Mexa em fogo baixo até engrossar e sirva para as crianças."
            ],
            "fonte_url": "https://www.tudogostoso.com.br/receita/arroz-doce-tradicional"
        },
        "mensagem": "Encontrei lotes de Leite com vencimento próximo! Que tal preparar um Arroz Doce Cremoso hoje para evitar desperdício?"
    }

def funcaoOrientarOperacaoUsuarioDora(duvida_operacional: str = "") -> Dict[str, Any]:
    """45. Fornece instruções passo a passo em linguagem simples para ensinar o operador a executar tarefas no aplicativo."""
    return {
        "sucesso": True,
        "status_code": 200,
        "intencao": "orientacao",
        "passo_a_passo": [
            "1. Toque no botão 'Gerenciar Estoque' na tela inicial.",
            "2. Escolha a opção '+ Entrada' para ler o código de barras ou '- Saída' para retirar um item.",
            "3. Se for descartar um produto vencido ou estragado, escolha o motivo de perda e digite a palavra PERDA em letras maiúsculas."
        ],
        "mensagem": "Eu te ajudo! Para dar baixa em um item vencido, abra a tela de Estoque, toque em Saída, escolha o motivo de perda e digite PERDA em maiúsculas."
    }
